package nl.rug.oop.introduction;

import java.time.LocalDateTime;

/**
 * The Assignment class represents an assignment given to students.
 */
public class Assignment {

    private String name;  // The name of the assignment.
    private final LocalDateTime deadline;  // The deadline for the assignment.

    /**
     * Constructs a new Assignment object.
     *
     * @param name     The name of the assignment.
     * @param deadline The deadline for the assignment.
     */
    public Assignment(String name, LocalDateTime deadline) {
        this.name = name;
        this.deadline = deadline;
    }

    /**
     * Returns the name of the assignment.
     *
     * @return A String representing the name of the assignment.
     */
    public String getAssignmentName() {
        return name;
    }

    /**
     * Returns the deadline for the assignment.
     *
     * @return A LocalDateTime object representing the deadline of the assignment.
     */
    public LocalDateTime getDeadline() {
        return deadline;
    }
}