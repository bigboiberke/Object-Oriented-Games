package nl.rug.oop.introduction;

import java.util.ArrayList;
import java.util.List;

/**
 * The Main class is the entry point of the application.
 * It creates a teaching assistant, students, an assignment, and a lecturer.
 * The lecturer gives lectures to the students, increasing their knowledge.
 * The students then do the assignment and the teaching assistant grades their submissions.
 */
public class Main {
    /**
     * The main method is the entry point of the application.
     *
     * @param args The command-line arguments.
     */
    public static void main(String[] args) {

        // Create a teaching assistant named Matt
        TeachingAssistant ta = new TeachingAssistant("Matt");

        // Create two students named Majd and Berke with initial knowledge level 1
        Student me = new Student("Majd", 1);
        Student you = new Student("Berke", 1);

        // Create an assignment named "OOP Assignment" with a deadline of one day from now
        Assignment assignment = new Assignment("OOP Assignment", java.time.LocalDateTime.now().plusDays(1));

        // Create a lecturer named Dr. John
        Lecturer lecturer = new Lecturer("Dr. John");

        // Create a list of students and add Majd and Berke to the list
        List<Student> students = new ArrayList<>();
        students.add(me);
        students.add(you);

        // The lecturer gives three lectures to the students
        for (int i = 0; i < 3; i++) {
            lecturer.lecture(students);
        }

        // The students do the assignment and their submissions are added to a list
        List<Submission> submissions = new ArrayList<>();
        submissions.add(me.doAssignment(assignment));
        submissions.add(you.doAssignment(assignment));

        // The teaching assistant grades the submissions for the assignment
        ta.gradeMultipleSubmissions(submissions, assignment);
    }
}