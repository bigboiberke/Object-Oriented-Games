package nl.rug.oop.introduction;

/**
 * The Student class represents a student who can obtain knowledge, do assignments and has a knowledge level.
 */
public class Student {
    private int knowledgeLevel;  // The knowledge level of the student, represented as an integer.
    private String name;  // The name of the student.

    /**
     * Constructs a new Student object.
     *
     * @param name           The name of the student.
     * @param knowledgeLevel The initial knowledge level of the student.
     */
    public Student(String name, int knowledgeLevel) {
        this.name = name;
        this.knowledgeLevel = knowledgeLevel;
    }

    /**
     * Increases the student's knowledge level by 1, up to a maximum of 6.
     */
    public void obtainKnowledge() {
        knowledgeLevel = Math.min(knowledgeLevel + 1, 6);
    }

    /**
     * Returns the name of the student.
     *
     * @return A String representing the student's name.
     */
    public String getName() {
        return name;
    }

    /**
     * Returns the knowledge level of the student.
     *
     * @return An integer representing the student's knowledge level.
     */
    public int getKnowledgeLevel() {
        return knowledgeLevel;
    }

    /**
     * Creates a new submission for an assignment.
     *
     * @param assignment The assignment for which the submission is being made.
     * @return A Submission object representing the student's submission for the assignment.
     */
    public Submission doAssignment(Assignment assignment) {
        return new Submission(this, assignment);
    }
}