package nl.rug.oop.introduction;

import java.util.List;
import java.util.Random;

/**
 * The TeachingAssistant class represents a TA who can grade students' submissions.
 */
public class TeachingAssistant {
    private String name;  // The name of the teaching assistant.

    /**
     * Constructs a new TeachingAssistant object.
     *
     * @param name The name of the teaching assistant.
     */
    public TeachingAssistant(String name) {
        this.name = name;
    }

    /**
     * Grades a student's submission for an assignment.
     * If the submission was made after the assignment's deadline, the grade is 0.
     * Otherwise, the grade is a random number between the submission's quality and 10.
     *
     * @param submission The submission to be graded.
     * @param assignment The assignment for which the submission was made.
     */
    public void gradeSubmission(Submission submission, Assignment assignment) {
        if (submission.getSubmissionDate().isAfter(assignment.getDeadline())) {
            System.out.println("Submission was late, grade is 0");
        } else {
            Random random = new Random();
            // Random number between submission quality and 10 (quality is at most 6)
            int grade = random.nextInt(5) + submission.getQuality();
            System.out.println("Submission grade is " + grade);
        }
        System.out.println(
                "TA's name: " + name +
                "\nAssignment name: " + assignment.getAssignmentName() +
                "\nStudent name: " + submission.getStudentName()
        );
    }

    /**
     * Grades multiple submissions for an assignment.
     *
     * @param submissions The list of submissions to be graded.
     * @param assignment  The assignment for which the submissions were made.
     */
    public void gradeMultipleSubmissions(List<Submission> submissions, Assignment assignment) {
        for (Submission submission : submissions) {
            gradeSubmission(submission, assignment);
        }
    }
}