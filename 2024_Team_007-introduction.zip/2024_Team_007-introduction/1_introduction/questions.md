# Question 1

What is the difference between a class and an object?

___

Answer:

___

A class is a blueprint, and an object is an instance of that blueprint


# Question 2

Given are the following three classes:

`Person.java`:

```java
public class Person {
    private String name;

    public Person(String name) {
        this.name = name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void printName() {
        System.out.println(name);
    }
}
```

`PersonModifier.java`:

```java
public class PersonModifier {

    public Person modifyPerson1(Person person) {
        person.setName("Bert");
        return person;
    }

    public Person modifyPerson2(Person person) {
        person.setName("Gerry");
        person = new Person("James");
        return person;
    }
}
```

`Main.java`:

```java
public class Main {

    public static void main(String[] args) {
        Person person1 = new Person("John");
        Person person2 = new Person("Bob");

        PersonModifier personModifier = new PersonModifier();
        Person modifiedPerson1 = personModifier.modifyPerson1(person1);
        Person modifiedPerson2 = personModifier.modifyPerson2(person2);

        person1.printName();
        person2.printName();
        modifiedPerson1.printName();
        modifiedPerson2.printName();
    }
}
```

What is the output of this program? Explain why.

___


Answer:

___

Bert
Gerry
Bert
James

When creating an instance of a class, a block of memory is allocated, and the instance is a pointer to it. This means that when you pass an object as a parameter to a method, you are passing the reference to the object, not a copy of the object itself. Thus, if the object's value gets modified, it will keep that value even after the method call is over. That's why person1's value was "John", but after the execution of 'modifyPerson1()', the value became "Bert" for both person1 and modifiedPerson1, because they both refer to the same memory block.

The same reasoning can be applied to why 'person2.printName();' prints "Gerry".

'modifiedPerson2.printName();' prints "James" because in 'modifyPerson2(Person person)', person is a pointer to a given Person instance. However, after the execution of 'person = new Person("James");', person becomes a pointer to a new Person instance, but only locally (in that specific method call).