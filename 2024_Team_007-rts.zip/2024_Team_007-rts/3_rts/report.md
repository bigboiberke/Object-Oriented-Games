# Report

John Doe (s1234567) & Foo Bar (s2345678)

## Introduction

> *Very briefly describe what your program does.*
 
>Expected length: ~100 words

## Program design
## Program Design

Our program is structured around the Model-View-Controller (MVC) architectural pattern, which is pivotal in ensuring a clear separation of concerns. This design pattern divides the program into three interconnected components, each responsible for distinct aspects of the application's functionality.

### Model

The Model component encapsulates the core data and business logic of our application. It is designed to be independent of the user interface, allowing it to be reused and tested separately from the rest of the application. In our case, the Model includes classes such as `Army`, which represents the game's armies, and `Node`, which represents locations within the game world. These classes are structured to not only store data but also to define the rules and interactions between different data elements.

### View

The View component is responsible for presenting data from the Model to the user. It listens for changes in the Model and updates the user interface accordingly. Our implementation utilizes the Swing library to create a graphical user interface (GUI) that displays the game state. Components such as `MapPanel` and `OptionsPanel` are part of the View. They render the game's armies, nodes, and other elements, providing a visual representation of the Model.

### Controller

The Controller acts as an intermediary between the Model and the View. It processes user input, manipulating the Model based on that input and updating the View to reflect changes in the Model. Classes like `TrackerController` and `LocationController` serve as Controllers in our application. They handle actions such as adding or removing nodes and moving armies, ensuring that user actions have the intended effect on the game state.

### Interaction Between Components

The interaction between the Model, View, and Controller is carefully managed to maintain the separation of concerns. The Model notifies the View of any changes in the game state through the Observer pattern. This allows the View to update itself without needing direct knowledge of the Model's inner workings. Similarly, the Controller modifies the Model in response to user input but does not directly update the View. Instead, changes in the Model trigger updates in the View through the same Observer mechanism.

### Design Decisions

One of our key design decisions was to use the Observer pattern to decouple the Model from the View and Controller. This choice was made to enhance the modularity of our code, allowing each component to be developed, tested, and modified independently. Another decision was to implement the game logic and data management within the Model, ensuring that the game could be easily extended or modified without requiring changes to the user interface.

In conclusion, our program's design follows the MVC pattern to separate the different aspects of the application, ensuring a clear division of responsibilities. This approach has allowed us to create a flexible and maintainable codebase that can be easily extended and adapted to new requirements.
> Expected length: as much as you need to explain the above.

## Evaluation of the program

> *Discuss the stability of your implementation. What works well? Are there any bugs? Is everything tested properly? Are there still features that have not been implemented? Also, if you had the time, what improvements would you make to your implementation? Are there things which you would have done completely differently?*

>Expected length: ~300-500 words

## Report
> * Majd Shuqeir & Berke Musellim.

> The developed program is a real-time strategy (RTS) game simulation implemented in Java. It allows the creation and manipulation of various game entities such as factions, units, and armies. The game state can be saved in a JSON format. The program follows the Model-nl.rug.oop.rts.View-Controller (MVC) design pattern, separating the game logic, user interface, and control flow. It also utilizes the Observer pattern to keep the user interface updated with changes in the game state. The user interface is built using Swing, implementing the Composite design pattern to create a hierarchy of components.

> The program is designed following the Model-nl.rug.oop.rts.View-Controller (MVC) architectural pattern. This pattern separates the application into three main components: the Model, the nl.rug.oop.rts.View, and the Controller.  The Model represents the data and the business logic of the application. It is responsible for managing the data and the rules that govern how the data can be manipulated. In this program, the Model is represented by classes such as Unit, Army, Faction, Node, Edge, and Tracker. These classes encapsulate the game's data and the rules governing their interactions.  The nl.rug.oop.rts.View is responsible for presenting the data to the user. It defines how the data is visually represented. In this program, the nl.rug.oop.rts.View is implemented using the Swing library, which provides a set of components for building graphical user interfaces. Classes like Panel and OptionsPanel are part of the nl.rug.oop.rts.View. They are responsible for rendering the game state to the user interface.  The Controller acts as an intermediary between the Model and the nl.rug.oop.rts.View. It processes user input from the nl.rug.oop.rts.View and updates the Model accordingly. In this program, classes like UnitController, LocationController, and TrackerController act as Controllers. They handle user input and manipulate the Model based on that input.  One of the key design decisions was to use the Observer pattern to keep the nl.rug.oop.rts.View updated with changes in the Model. This allows the Model to be independent of the nl.rug.oop.rts.View and Controller. The Model doesn't need to know anything about the UI or user input. It just notifies Observers about changes to its state. This leads to a decoupled and flexible design where changes in the Model don't affect the nl.rug.oop.rts.View or Controller and vice versa.  

>The implementation of our program is stable, with all features functioning as expected and no errors reported during operation. One of the key features that works well is the movement of armies. The armies move as intended, and the visual representation of these movements in the user interface is accurate and responsive.  However, despite the overall functionality and stability of the program, it currently lacks a feature for parsing data to JSON. This feature would allow the game state to be saved and loaded in a standardized format, enhancing the usability of the program and allowing for game progress to be preserved between sessions.  In retrospect, there are aspects of the project we might have approached differently. For instance, incorporating the JSON parsing feature earlier in the development process could have been beneficial. Despite these challenges, we have learned valuable lessons about Java programming, the MVC design pattern, and working on larger projects.

## Questions

Please answer the following questions:

1. In this assignment, the program should follow the Model nl.rug.oop.rts.View Controller (MVC) pattern. Please explain the design of the program in terms of the MVC pattern. Specifically try to answer the following questions:
   - MVC consists of three components: Model, view and controller. Can you please explain the role of each component? Please provide examples of these roles from the assignment. How are these three roles (i.e. Model, view and controller) are implemented in the assignment?
   - MVC enforces special constraints on the dependencies between its three components: Model, view and controller. Please explain these constraints, and why are they important?
___

Answer:
The Model-nl.rug.oop.rts.View-Controller (MVC) pattern is a design pattern that separates an application into three interconnected components: the Model, the nl.rug.oop.rts.View, and the Controller.

- **Model**: The Model represents the data and the business logic of the application. It is responsible for managing the data and the rules that govern how the data can be manipulated. In this assignment, the Model is represented by classes such as `Unit`, `Army`, `Faction`, `Node`, `Edge`, and `Tracker`. These classes encapsulate the game's data and the rules governing their interactions.

- **nl.rug.oop.rts.View**: The nl.rug.oop.rts.View is responsible for presenting the data to the user. It defines how the data is visually represented. In this assignment, the nl.rug.oop.rts.View is implemented using the Swing library, which provides a set of components for building graphical user interfaces. Classes like `Panel` and `OptionsPanel` are part of the nl.rug.oop.rts.View. They are responsible for rendering the game state to the user interface.

- **Controller**: The Controller acts as an intermediary between the Model and the nl.rug.oop.rts.View. It processes user input from the nl.rug.oop.rts.View and updates the Model accordingly. In this assignment, classes like `UnitController`, `LocationController`, and `TrackerController` act as Controllers. They handle user input and manipulate the Model based on that input.

The MVC pattern enforces special constraints on the dependencies between its three components. The Model should not depend on either the nl.rug.oop.rts.View or the Controller. This means that the Model does not know anything about the user interface or user input. It just notifies Observers (usually the nl.rug.oop.rts.View and sometimes the Controller) about changes to its state. This leads to a decoupled and flexible design where changes in the Model don't affect the nl.rug.oop.rts.View or Controller and vice versa.

The nl.rug.oop.rts.View and the Controller depend on the Model but not on each other. This means that changes in the Controller do not affect the nl.rug.oop.rts.View and vice versa. This separation allows you to change the user interface without affecting the underlying business logic and control flow, and vice versa.

These constraints are important because they lead to a decoupled and flexible design. Each component can be developed, tested, and modified independently of the others. This makes the application easier to maintain and extend over time.
___

2. The Swing library provides the ability to create nested user interface components. In this assignment, you created multiple JPanel components on the user interface. These contain other user interface components to build-up a tree of user interface components.
Which design pattern does Swing implement to create a hierarchy of user interface components? Please explain this pattern and how it is implemented in Swing.

___

Answer:

The Swing library implements the Composite design pattern to create a hierarchy of user interface components.

The Composite design pattern allows you to compose objects into tree structures to represent part-whole hierarchies. It lets clients treat individual objects and compositions of objects uniformly. In the context of Swing, this pattern is used to create complex user interfaces by nesting simpler components within more complex ones.

For example, a `JPanel` (a composite component) can contain other Swing components like `JButton`, `JLabel`, or even other `JPanel` instances. Each of these components, whether simple or composite, implements the `Component` interface. This common interface allows all components, simple or composite, to be treated uniformly.

In Swing, the `Component` interface defines methods that are common to all user interface elements, such as `paint()`, `repaint()`, and `revalidate()`. Composite components like `JPanel` also have methods to manage their child components, such as `add(Component)`, `remove(Component)`, and `getComponent(int)`.

This design allows complex user interfaces to be built from simple components. It also simplifies the handling of user interface events, as an event can be processed by a component or passed up the component hierarchy.
___

3. The Observer pattern is useful to implement the MVC pattern. Can you please explain the relationship between the Observer pattern and the MVC pattern?
Please provide an example from the assignment on how the Observer pattern supports implementing the MVC pattern.

___

Answer:

The Observer pattern and the Model-nl.rug.oop.rts.View-Controller (MVC) pattern are closely related and often used together in applications. The Observer pattern is a design pattern where an object, called the subject, maintains a list of its dependents, called observers, and notifies them automatically of any state changes.
In the context of the MVC pattern, the Model is typically the subject, and the Views and sometimes Controllers are the observers. When the state of the Model changes (for example, when data is updated), it notifies all of its observers. The Views then update themselves to reflect the new state of the Model. This allows for a separation of concerns, where the Model does not need to know anything about the Views, leading to a more modular and maintainable codebase.
In the provided assignment, the Observer pattern could be used to update the game's user interface whenever the game state changes. For example, when an Army is added to a SuitableForArmy location, the LocationController could update the SuitableForArmy object (the Model), which would then notify all of its observers. The Panel or OptionsPanel (the Views) would be observers and would update themselves to reflect the new state of the SuitableForArmy object. This ensures that the user interface always accurately represents the current game state.

___

## Process evaluation

> *Describe shortly the process that led to the final code and the report. What was easy, what was difficult? Did you make interesting mistakes? What have you learned from this assignment?*

> Expected length: ~150 words

## Conclusions

> *Add a very short summary/concluding remarks here*
