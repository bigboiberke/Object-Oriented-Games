package nl.rug.oop.rts.Model.Events;

import nl.rug.oop.rts.Controller.ArmyController;
import nl.rug.oop.rts.Model.Army.Army;

/**
 * Represents an event that duplicates an army within the game.
 * This class extends the Event class, inheriting its basic event functionality
 * and adding a specific action to duplicate an army when the event is activated.
 */
public class DuplicateArmyEvent extends Event{

    /**
     * Constructor for the DuplicateArmyEvent class.
     * Initializes the name of the event.
     */
    public DuplicateArmyEvent() {
        super("Duplicate Army");
    }

    /**
     * Activates the duplicate army event for a specified army.
     * Duplicates the army.
     *
     * @param army The army that the event is activated for.
     */
    @Override
    public void activate(Army army) {
        ArmyController armyController = new ArmyController(army);
        armyController.duplicateArmy();
    }
}
