package nl.rug.oop.rts.View;

import nl.rug.oop.rts.Model.Place.Tracker;

import javax.swing.*;

/**
 * This class represents the main frame of the RTS game.
 * It extends JFrame and contains the main panel and options panel of the game.
 */
public class Frame extends JFrame{

    /**
     * Constructs a new Frame for the RTS game.
     * It sets the title of the frame, creates a new Panel and OptionsPanel, and sets their listeners.
     * It also creates a JSplitPane to hold the options panel and the main panel, and adds it to the frame.
     * Finally, it packs the frame, maximizes it, sets the default close operation, and makes it visible.
     */
    public Frame(){
        setTitle("RTS Game");
        Tracker tracker = new Tracker();
        MapPanel mapPanel = new MapPanel(tracker);
        OptionsPanel optionsPanel = new OptionsPanel(tracker);
        OverviewPanel overViewPanel = new OverviewPanel(tracker);
        mapPanel.setNodeSelectedObserver(optionsPanel);
        JSplitPane infoPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, overViewPanel, optionsPanel);
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, infoPane, mapPanel);
        add(splitPane);
        pack();
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximize the frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
}