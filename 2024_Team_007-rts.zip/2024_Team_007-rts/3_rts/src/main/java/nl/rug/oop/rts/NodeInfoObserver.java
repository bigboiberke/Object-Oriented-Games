package nl.rug.oop.rts;

/**
 * The {@code NodeInfoObserver} interface defines the methods that must be implemented by any class
 * that wishes to observe and react to node-related events within the game. Observers can respond to
 * general updates or specific actions such as clicking on an empty space within the game environment.
 */
public interface NodeInfoObserver {
    /**
     * Called to notify the observer of a general update that requires attention.
     * Implementations should define how the observer reacts to such updates, which may include
     * refreshing UI components or updating internal state based on the latest game data.
     */
    void update();

    /**
     * Called when the user clicks on an area that does not correspond to any interactive game element.
     * Implementations should define the response to this action, which could range from clearing
     * selected elements to showing a generic information panel.
     */
    void clickedOnNothing();
}