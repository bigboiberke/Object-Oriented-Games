package nl.rug.oop.rts.Model.Place;

import lombok.Getter;
import nl.rug.oop.rts.Model.Army.Army;
import nl.rug.oop.rts.TrackerObserver;

import java.util.ArrayList;
import java.util.List;

/**
 * The Tracker class is responsible for tracking nodes and edges in the game.
 * It maintains a list of nodes and edges, and provides methods for adding and removing nodes and edges.
 */
public class Tracker {
    /**
     * The list of nodes being tracked.
     */
    @Getter
    private List<Node> nodes;

    /**
     * List of views that are observing tracker.
     */
    @Getter
    private List<TrackerObserver> observers;

    /**
     * The list of edges being tracked.
     */
    @Getter
    private List<Edge> edges;

    /**
     * Constructor for the Tracker class.
     * Initializes the lists of nodes and edges.
     */
    public Tracker() {
        this.nodes = new ArrayList<>();
        this.edges = new ArrayList<>();
        this.observers = new ArrayList<>();
    }

    /**
     * Adds a node to the list of nodes being tracked.
     *
     * @param node The node to be added.
     */
    public void addNode(Node node) {
        this.nodes.add(node);
    }

    /**
     * Adds an edge to the list of edges being tracked.
     *
     * @param edge The edge to be added.
     */
    public void addEdge(Edge edge) {
        this.edges.add(edge);
    }

    /**
     * Removes a node from the list of nodes being tracked.
     * Also removes all edges connected to the node from the list of edges being tracked.
     *
     * @param node The node to be removed.
     */
    public void removeNode(Node node){
        for (Edge edge : node.getEdgesConnected()) {
            removeEdge(edge);
        }
        this.nodes.remove(node);
    }

    /**
     * Removes an edge from the list of edges being tracked.
     *
     * @param edge The edge to be removed.
     */
    public void removeEdge(Edge edge){
        this.edges.remove(edge);
    }

    /**
     * Returns a list of all armies in the game.
     *
     * @return A list of all armies in the game.
     */
    public List<Army> getArmies() {
        List<Army> armies = new ArrayList<>();
        for (Node node : nodes) {
            armies.addAll(node.getArmies());
        }
        for (Edge edge : edges) {
            armies.addAll(edge.getArmies());
        }
        return armies;
    }

    /**
     * Retrieves a list of armies by their team number.
     * This method iterates through all nodes and edges in the game,
     * collecting armies that belong to the specified team.
     * It effectively filters all armies based on the team number, allowing for easy access to team-specific armies.
     *
     * @param team The team number for which armies are to be retrieved.
     * @return A list of {@link Army} objects that belong to the specified team.
     */
    public List<Army> getArmiesByTeam(int team){
        List<Army> armies = new ArrayList<>();
        for (Node node : nodes) {
            for (Army army : node.getArmies()) {
                if (army.getTeam() == team) {
                    armies.add(army);
                }
            }
        }
        for (Edge edge : edges) {
            for (Army army : edge.getArmies()) {
                if (army.getTeam() == team) {
                    armies.add(army);
                }
            }
        }
        return armies;
    }

    /**
     * Adds a tracker observer.
     *
     * @param observer The observer to be added.
     */
    public void addObserver(TrackerObserver observer) {
        observers.add(observer);
    }

    /**
     * Removes a tracker observer.
     *
     * @param observer The observer to be removed.
     */
    public void removeObserver(TrackerObserver observer) {
        observers.remove(observer);
    }

    /**
     * Notifies all registered observers of a change.
     * This method iterates through the list of observers and calls their update method,
     * allowing them to react to changes in the Tracker's state.
     */
    public void notifyObservers() {
        for (TrackerObserver observer : observers) {
            observer.update();
        }
    }
}