package nl.rug.oop.rts.Model.Army;

import lombok.Getter;
import lombok.Setter;

/**
 * This class represents a Unit in the game.
 * It contains information about the unit's name, health, and damage.
 */
public class Unit {
    @Getter
    @Setter
    private String name;
    @Getter
    @Setter
    private int health;
    @Getter
    private int damage;

    /**
     * Constructs a new Unit with a given faction.
     * The unit's name, health, and damage are determined based on the faction's random unit.
     *
     * @param faction The faction of the unit.
     */
    public Unit(Faction faction) {
        Faction.Units units = faction.getRandomUnit();
        this.name = units.getName();
        this.health = units.getHealth();
        this.damage = units.getDamage();
    }

    public boolean isAlive() {
        return (health >= 0);
    }
}