package nl.rug.oop.rts;

import com.formdev.flatlaf.FlatDarculaLaf;
import nl.rug.oop.rts.View.Frame;

/**
 * The Main class is the entry point of the application.
 * It sets up the application's look and feel, creates nodes and edges, and initializes the application frame.
 */
public class Main {
    /**
     * The main method is the entry point of the application.
     * It sets up the application's look and feel, creates nodes and edges, and initializes the application frame.
     *
     * @param args Command-line arguments passed to the application.
     * This application does not use command-line arguments.
     */
    public static void main(String[] args) {
        // Set up the application's look and feel to dark mode
        FlatDarculaLaf.setup();
        // Initialize the application frame
        new Frame();
    }
}