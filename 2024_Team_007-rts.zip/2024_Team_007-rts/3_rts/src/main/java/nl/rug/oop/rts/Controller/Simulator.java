package nl.rug.oop.rts.Controller;

import nl.rug.oop.rts.Model.Army.Army;
import nl.rug.oop.rts.Model.Place.Edge;
import nl.rug.oop.rts.Model.Place.Node;
import nl.rug.oop.rts.Model.Place.Tracker;

/**
 * The Simulator class is responsible for simulating the movement of armies
 * across nodes and edges in the game.
 */
public class Simulator {

    /**
     * The forward method advances the game by one time step. It moves all armies
     * from their current nodes to the next nodes along their paths. If an army
     * is on an edge, it moves the army along the edge.
     *
     * @param tracker The tracker object that keeps track of all nodes and edges in the game.
     */
    public void forward(Tracker tracker) {
        // Iterate over all nodes in the tracker
        for (Node node : tracker.getNodes()) {
            int i = 0;
            // While there are armies on the node, move each army
            while (node.getArmies().size() > i) {
                ArmyController armyController = new ArmyController(node.getArmies().get(i));
                armyController.move();
                i++;
            }
        }
        // Iterate over all edges in the tracker
        for (Edge edge : tracker.getEdges()) {
            int i = 0;
            // While there are armies on the edge, move each army
            while (edge.getArmies().size() > i){
                Army army = edge.getArmies().get(i);
                // If the army was not on a node in the previous time step, move it
                if (!army.isWasOnNode()) {
                    ArmyController armyController = new ArmyController(army);
                    armyController.move();
                } else {
                    // If the army was on a node in the previous time step, do not move it
                    // and set its wasOnNode status to false
                    army.setWasOnNode(false);
                    i++;
                }
            }
        }
        TrackerController trackerController = new TrackerController(tracker);
        trackerController.updateObservers();
    }
}