package nl.rug.oop.rts.Controller;

import nl.rug.oop.rts.View.MapPanel;
import lombok.Getter;
import lombok.Setter;
import nl.rug.oop.rts.Model.Place.Node;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * MouseListener class extends MouseAdapter to handle mouse events.
 */
public class MouseListener extends MouseAdapter {
    private final MapPanel panel;
    @Setter
    @Getter
    private Node selectedNode;

    /**
     * Constructor for MouseListener.
     *
     * @param panel The panel where the mouse events are to be handled.
     */
    public MouseListener(MapPanel panel) {
        this.panel = panel;
    }

    /**
     * Handles mouse pressed event.
     *
     * @param e The mouse event.
     */
    @Override
    public void mousePressed(MouseEvent e) {
        this.panel.setPrevPoint(e.getPoint());
        clickedOnANode(e);
    }

    /**
     * Handles mouse clicked event.
     *
     * @param e The mouse event.
     */
    @Override
    public void mouseClicked(MouseEvent e) {
        TrackerController trackerController = new TrackerController(panel.getTracker());
        if (clickedOnANode(e) && selectedNode != panel.getFirstNodeForEdge()){
            if (panel.isAddingEdge()) {
                trackerController.createEdge(panel.getFirstNodeForEdge(), selectedNode);
            } else {
                trackerController.removeEdgeByNodes(selectedNode, panel.getFirstNodeForEdge());
            }
        }
    }

    /**
     * Checks if a node was clicked.
     *
     * @param e The mouse event.
     *
     * @return True if a node was clicked, false otherwise.
     */
    private boolean clickedOnANode(MouseEvent e) {
        for (Node node : panel.getTracker().getNodes()) {
            if ( ( e.getX() > node.getX() && e.getX() < node.getX()+75 ) &&
                    ( e.getY() > node.getY() && e.getY() < node.getY()+75 )) {
                selectedNode = node;
                notifyOptionsPanel(node);
                panel.update();
                panel.setCurrentPoint(new Point(node.getX(), node.getY()));
                return true;
            }
        }
        selectedNode = null;
        notifyOptionsPanel(null);
        panel.clickedOnNothing();
        return false;
    }

    /**
     * Notifies other panel about the selected node.
     *
     * @param nodeInfo The selected node.
     */
    private void notifyOptionsPanel(Node nodeInfo) {
        panel.notifyListener(nodeInfo);
    }
}