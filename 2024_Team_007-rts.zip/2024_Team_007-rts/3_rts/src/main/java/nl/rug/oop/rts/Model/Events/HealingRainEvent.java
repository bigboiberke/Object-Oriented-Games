package nl.rug.oop.rts.Model.Events;

import nl.rug.oop.rts.Model.Army.Army;
import nl.rug.oop.rts.Model.Army.Unit;

/**
 * The HealingRainEvent class represents a healing rain event in the game.
 * It extends the Event class and overrides the activate method to heal all units in an army.
 */
public class HealingRainEvent extends Event{

    /**
     * Constructor for the HealingRainEvent class.
     * Initializes the name of the event.
     */
    public HealingRainEvent() {
        super("Healing Rain");
    }

    /**
     * Activates the healing rain event for a specified army.
     * All units in the army have their health increased by 10.
     *
     * @param army The army that the event is activated for.
     */
    @Override
    public void activate(Army army) {
        for (Unit unit : army.getUnits()) {
            unit.setHealth(unit.getHealth() + 10);
        }
    }
}
