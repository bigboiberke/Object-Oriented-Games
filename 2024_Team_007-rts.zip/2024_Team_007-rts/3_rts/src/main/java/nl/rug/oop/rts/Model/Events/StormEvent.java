package nl.rug.oop.rts.Model.Events;

import nl.rug.oop.rts.Model.Army.Army;

/**
 * The StormEvent class represents a storm event in the game.
 * It extends the Event class and overrides the activate method to remove units from an army.
 */
public class StormEvent extends Event{

    /**
     * Constructor for the StormEvent class.
     * Initializes the name of the event.
     */
    public StormEvent() {
        super("Storm");
    }

    /**
     * Activates the storm event for a specified army.
     * Removes 5 random units from the army.
     *
     * @param army The army that the event is activated for.
     */
    @Override
    public void activate(Army army) {
        for (int i = 0; i < 5; i++) {
            if (army.isAlive()){
                army.removeUnit(army.getRandomUnit());
            }
        }
    }
}