package nl.rug.oop.rts.Controller;

import nl.rug.oop.rts.Model.Place.*;
import java.io.IOException;
import java.lang.reflect.Field;
import java.nio.file.*;
import java.util.List;
import java.util.Random;

/**
 * The TrackerController class is responsible for controlling the Tracker.
 * It provides methods for creating and removing nodes and edges in the Tracker.
 */
public class TrackerController {
    /**
     * The Tracker that this TrackerController controls.
     */
    private Tracker tracker;

    /**
     * The quote character used in JSON strings.
     */
    private static final String QUOTE = "\"";

    /**
     * Constructor for the TrackerController class.
     *
     * @param tracker The Tracker that this TrackerController will control.
     */
    public TrackerController(Tracker tracker) {
        this.tracker = tracker;
    }

    /**
     * Removes a node from the Tracker.
     *
     * @param node The node to be removed.
     */
    public void removeNode(Node node) {
        tracker.removeNode(node);
        updateObservers();
    }

    /**
     * Creates a new node with random coordinates and adds it to the Tracker.
     */
    public void createNode() {
        Random random = new Random();
        Node node = new Node(random.nextInt(501), random.nextInt(501));
        tracker.addNode(node);
        updateObservers();
    }

    /**
     * Creates a new edge between two nodes and adds it to the Tracker.
     *
     * @param startNode The start node of the edge.
     * @param endNode   The end node of the edge.
     */
    public void createEdge(Node startNode, Node endNode) {
        Edge edge = new Edge(startNode, endNode);
        tracker.addEdge(edge);
        updateObservers();
    }

    /**
     * Removes an edge between two nodes from the Tracker.
     * Also removes the edge from the start and end nodes.
     *
     * @param startNode The start node of the edge.
     * @param endNode   The end node of the edge.
     */
    public void removeEdgeByNodes(Node startNode, Node endNode) {
        for (Edge edge : tracker.getEdges()) {
            if (edge.getStartNode().equals(startNode) && edge.getEndNode().equals(endNode) ||
                    edge.getStartNode().equals(endNode) && edge.getEndNode().equals(startNode)) {
                tracker.removeEdge(edge);
                startNode.removeEdge(edge);
                endNode.removeEdge(edge);
                break;
            }
        }
        updateObservers();
    }

    /**
     * Updates the view of the Tracker.
     */
    public void updateObservers() {
        tracker.notifyObservers();
    }

    /**
     * Saves the current state of the Tracker to a JSON file.
     * This method serializes the Tracker object into a JSON string and writes it to a file.
     * The serialization process excludes fields listed in {@code notWantedFields}.
     *
     * @param filePath The path where the JSON file will be saved. If the path does not end with
     *                 ".json", the extension is appended.
     * @param notWantedFields A list of field names to be excluded from serialization.
     * @throws IllegalAccessException If an error occurs accessing the fields of the
     *                  Tracker object during serialization.
     * @throws IOException If an error occurs writing the JSON string to the file.
     */
    public void saveToJSON(String filePath, List<String> notWantedFields)
            throws IllegalAccessException, IOException {
        // Ensure the file path ends with ".json"
        if (!filePath.endsWith(".json")) {
            filePath += ".json";
        }
        Path destination = Paths.get(filePath);
        // Initialize the JSON data string with an opening brace
        String jsonData = "{\n";
        // Convert the Tracker object to a JSON string, excluding specified fields
        jsonData = convertObject(tracker, notWantedFields, 1, jsonData);
        // Close the JSON data string with a closing brace
        jsonData += "}";
        // Write the JSON data to the specified file
        Files.writeString(destination, jsonData);
        // Log the path where the JSON data was saved
        System.out.println("JSON data saved to " + destination.toAbsolutePath());
    }

    private String convertObject(Object object, List<String> notWantedFields, int level, String jsonData)
            throws IllegalAccessException {
        Field[] fields = object.getClass().getDeclaredFields();
        for (int i = 0; i < fields.length; i++) {
            Field field = fields[i];
            if (notWantedFields.contains(field.getName())) {
                continue;
            }
            field.setAccessible(true);

            jsonData += printIndentation(level);
            jsonData += QUOTE + field.getName() + QUOTE + ": ";

            if (field.getType().isPrimitive()) {
                jsonData += field.get(object);
            } else if (field.getType().isAssignableFrom(String.class)) {
                jsonData += QUOTE + field.get(object) + QUOTE;
            } else if (field.getType().isAssignableFrom(List.class)){
                jsonData += "[";
                jsonData = fieldIsList(field, level + 1, object, notWantedFields, jsonData);
                jsonData += "]";
            } else if (field.getType().equals(Node.class)){
                Node node = (Node) field.get(object);
                jsonData += QUOTE + node.getName() + QUOTE;
            } else if (field.getType().isEnum()) {
                jsonData += QUOTE + ((Enum<?>) field.get(object)).name() + QUOTE;
            }

            // Append comma if not the last field
            if (i < fields.length - 1) {
                jsonData += ",\n";
            } else {
                jsonData += "\n";
                return jsonData;
            }
        }
        jsonData += printIndentation(level);
        jsonData += "\"" + object.getClass().getSimpleName() + "\"\n";
        return jsonData;
    }

    private String fieldIsList(Field field, int level,
                               Object parentObject, List<String> notWantedFields, String jsonData) {
        try {
            // Cast the field to a list of objects and check if it is empty
            List<Object> list = (List<Object>) field.get(parentObject);
            if (list.isEmpty()) {
                return jsonData;
            }
            jsonData += "\n";
            // Loop through the list and append each object's fields
            for (int i = 0; i < list.size(); i++) {
                Object object = list.get(i);
                jsonData += printIndentation(level);
                jsonData += "{\n";
                jsonData = convertObject(object, notWantedFields, level + 1, jsonData);
                jsonData += printIndentation(level);
                jsonData += "}";
                if (i < list.size() - 1) {
                    jsonData += ",\n";
                } else {
                    jsonData += "\n";
                }
            }
            jsonData += printIndentation(level - 1);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return jsonData;
    }

    private String printIndentation(int level){
        StringBuilder indentation = new StringBuilder();
        for (int i = 0; i < level; i++) {
            indentation.append("\t");
        }
        return indentation.toString();
    }
}