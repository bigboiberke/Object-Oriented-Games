package nl.rug.oop.rts.Controller;

import nl.rug.oop.rts.Model.Army.Army;
import nl.rug.oop.rts.Model.Army.Unit;
import nl.rug.oop.rts.Model.Place.Node;
import java.util.Random;

/**
 * The ArmyController class is responsible for controlling the actions of an Army.
 * It includes methods for moving the army and handling conflicts with other armies.
 */
public class ArmyController {
    private Army army;

    /**
     * Constructor for the ArmyController class.
     *
     * @param army The army to be controlled.
     */
    public ArmyController(Army army) {
        this.army = army;
    }

    public void duplicateArmy(){
        army.duplicate();
    }

    /**
     * Moves the army from its current location to a new location.
     * If the army is currently on a node, it moves to a random edge connected to the node.
     * If the army is currently on an edge, it moves to a random node connected to the edge.
     */
    public void move() {
        if (army.isOnNode()) {
            if (((Node) army.getLocation()).getEdgesConnected().isEmpty()) {
                return;
            }
            army.getLocation().removeArmy(army);
            army.setLocation(army.getLocation().getRandomDestination());
            army.setOnNode(false);
            army.setWasOnNode(true);
        } else {
            army.getLocation().removeArmy(army);
            army.setLocation(army.getLocation().getRandomDestination());
            army.setOnNode(true);
            army.setWasOnNode(false);
        }
        System.out.println("Army has moved");
        army.getLocation().addArmy(army);
        checkConflict();
        LocationController locationController = new LocationController(army.getLocation());
        locationController.activateEvent(army);
        System.out.println("Army has " + army.getUnits().size() + " units left");
        if (!army.isAlive()) {
            army.getLocation().removeArmy(army);
        }
    }

    /**
     * Checks for conflicts with other armies at the same location.
     */
    public void checkConflict() {
        for (Army army : army.getLocation().getArmies()) {
            if (army.getTeam() != this.army.getTeam()) {
                conflict(army);
            }
        }
    }

    /**
     * Handles a conflict with another army.
     *
     * @param armyToFight The army to fight with.
     */
    private void conflict(Army armyToFight){
        Random random = new Random();
        while (armyToFight.isAlive() && this.army.isAlive()) {
            Unit unitOne = armyToFight.getUnits().get(random.nextInt(armyToFight.getUnits().size()));
            Unit unitTwo = this.army.getUnits().get(random.nextInt(this.army.getUnits().size()));
            UnitController unitOneController = new UnitController(unitOne);
            if (unitOneController.fight(unitTwo)){
                this.army.removeUnit(unitTwo);
            } else {
                armyToFight.removeUnit(unitOne);
            }
        }
        if (!armyToFight.isAlive()) {
            armyToFight.getLocation().removeArmy(armyToFight);
        } else {
            this.army.getLocation().removeArmy(this.army);
        }
    }
}