package nl.rug.oop.rts.Model.Army;

import lombok.Getter;
import lombok.Setter;
import nl.rug.oop.rts.ArmySuitable;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Represents an army in a real-time strategy (RTS) game.
 * Each army has a unique ID, name, faction, team, and a list of units.
 * Armies can occupy nodes, and their presence on a node is tracked.
 */
public class Army {
    // Unique identifier for each army instance
    static final AtomicLong NEXT_ID = new AtomicLong(0);
    private final long id = NEXT_ID.getAndIncrement();

    @Getter
    @Setter
    private String name; // Name of the army
    @Getter
    @Setter
    private Faction faction; // Faction to which the army belongs
    @Getter
    @Setter
    private int team; // Team number, determined by faction
    @Getter
    @Setter
    private boolean isOnNode; // Flag indicating if the army is currently on a node
    @Getter
    @Setter
    private boolean wasOnNode; // Flag indicating if the army was on a node previously
    @Getter
    @Setter
    private ArmySuitable location; // Current location of the army
    @Getter
    @Setter
    private List<Unit> units; // List of units in the army

    /**
     * Constructs an Army with a specified faction and location.
     * Initializes the army with a random number of units.
     *
     * @param faction The faction of the army.
     * @param location The initial location of the army.
     */
    public Army(Faction faction, ArmySuitable location) {
        this.name = faction + " " + id;
        this.faction = faction;

        // Assign team based on faction
        if (faction.equals(Faction.MEN) || faction.equals(Faction.ELVES) || faction.equals(Faction.DWARVES)) {
            this.team = 1;
        } else {
            this.team = 2;
        }

        // Initialize units with a random number of units based on faction
        Random random = new Random();
        this.units = new ArrayList<>();
        for (int i = 0; i < random.nextInt(51) + 1; i++) {
            units.add(new Unit(faction));
        }
        this.wasOnNode = false;
        this.isOnNode = true;
        this.location = location;
    }

    /**
     * Adds a unit to the army.
     *
     * @param unit The unit to be added.
     */
    public void addUnit(Unit unit){
        units.add(unit);
    }

    /**
     * Removes a unit from the army.
     *
     * @param unit The unit to be removed.
     */
    public void removeUnit(Unit unit){
        units.remove(unit);
    }

    /**
     * Retrieves a random unit from the army.
     *
     * @return A randomly selected unit from the army.
     */
    public Unit getRandomUnit() {
        Random random = new Random();
        return units.get(random.nextInt(units.size()));
    }

    /**
     * Checks if the army is alive, i.e., if it has any units.
     *
     * @return true if the army has at least one unit, false otherwise.
     */
    public boolean isAlive(){
        return !this.units.isEmpty();
    }

    /**
     * Duplicates the army, creating a new army with the same units and properties.
     * The new army is added to the same location as the original.
     */
    public void duplicate(){
        Army army = new Army(this.faction, this.location);
        army.units.clear();
        army.setOnNode(this.isOnNode);
        army.setWasOnNode(this.wasOnNode);
        for (Unit unit : this.units){
            army.addUnit(unit);
        }
        this.location.addArmy(army);
    }
}