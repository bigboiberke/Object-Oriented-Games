package nl.rug.oop.rts.Controller;

import nl.rug.oop.rts.Model.Army.Unit;

/**
 * The UnitController class is responsible for controlling a Unit.
 * It provides methods for attacking other units and for fighting (a sequence of attacks) with another unit.
 */
public class UnitController {
    /**
     * The Unit that this UnitController controls.
     */
    private Unit unit;

    /**
     * Constructor for the UnitController class.
     *
     * @param unit The Unit that this UnitController will control.
     */
    public UnitController(Unit unit) {
        this.unit = unit;
    }

    /**
     * Makes the controlled unit attack another unit.
     * The health of the unit being attacked is reduced by the damage of the attacking unit.
     *
     * @param unitAttacking The unit that is attacking.
     * @param unitGettingAttacked The unit that is being attacked.
     */
    public void attack(Unit unitAttacking, Unit unitGettingAttacked) {
        unitGettingAttacked.setHealth(unitGettingAttacked.getHealth() - unitAttacking.getDamage());
    }

    /**
     * Makes the controlled unit fight with another unit.
     * The units take turns attacking each other until one of them is no longer alive.
     * If the controlled unit is the last one standing, the method returns true. Otherwise, it returns false.
     *
     * @param unitToFight The unit to fight with.
     * @return True if the controlled unit is the last one standing, false otherwise.
     */
    public boolean fight(Unit unitToFight) {
        while (true) {
            attack(unit, unitToFight);
            if (!unitToFight.isAlive()) {
                return true;
            }
            attack(unitToFight, unit);
            if (!unit.isAlive()) {
                return false;
            }
        }
    }
}