package nl.rug.oop.rts;

import nl.rug.oop.rts.Model.Place.Node;

/**
 * This interface represents a listener for node selection events.
 * It provides a method to handle a node selection event.
 */
public interface NodeSelectedObserver {
    /**
     * Handles a node selection event.
     * This method is called when a node is selected.
     *
     * @param nodeInfo The selected node.
     */
    void nodeSelected(Node nodeInfo);
}