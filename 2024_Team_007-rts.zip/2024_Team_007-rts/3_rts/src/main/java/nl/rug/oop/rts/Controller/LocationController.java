package nl.rug.oop.rts.Controller;

import nl.rug.oop.rts.ArmySuitable;
import nl.rug.oop.rts.Model.Events.Event;
import nl.rug.oop.rts.Model.Events.EventEnum;
import nl.rug.oop.rts.Model.Army.Army;
import nl.rug.oop.rts.Model.Army.Faction;

import java.util.Random;

/**
 * The LocationController class is responsible for controlling a location in the game.
 * It provides methods for activating events at the location,
 * adding events to the location, and adding an army to the location.
 */
public class LocationController {
    /**
     * The location that this LocationController controls.
     */
    private ArmySuitable location;

    /**
     * Constructor for the LocationController class.
     *
     * @param location The location that this LocationController will control.
     */
    public LocationController(ArmySuitable location) {
        this.location = location;
    }

    /**
     * Adds a specified number of random events to the location.
     * The events are chosen randomly from the list of all possible events.
     *
     * @param location The location to which the events are added.
     */
    public void addEvents(ArmySuitable location) {
        Random random = new Random();
        for (int i = 0; i < 2; i++) {
            // Get a random event from the list of all possible events but only add it if it is not already present
            EventEnum eventEnum = EventEnum.values()[random.nextInt(EventEnum.values().length)];
            Event event = eventEnum.getEvent();
            if (!location.getEvents().contains(event)) {
                location.addEvent(event);
            }
        }
    }

    /**
     * Activates a random event at the location for a specified army.
     * The event is chosen randomly from the list of events at the location.
     * The event is activated with a 50% probability.
     *
     * @param army The army for which the event is activated.
     */
    public void activateEvent(Army army) {
        Random random = new Random();
        if (random.nextBoolean()) {
            Event event = location.getEvents().get(random.nextInt(location.getEvents().size()));
            event.activate(army);
        }
    }

    /**
     * Adds an army to the location.
     *
     * @param army The army to be added.
     */
    public void addArmy(Army army) {
        location.addArmy(army);
    }

    /**
     * Adds an army of a specified faction to the location.
     *
     * @param faction The faction of the army to be added.
     */
    public void addArmyOfFaction(Faction faction) {
        Army army = new Army(faction, location);
        addArmy(army);
    }

    /**
     * Removes an army from the location.
     *
     * @param army The army to be removed.
     */
    public void removeArmy(Army army) {
        location.removeArmy(army);
    }
}