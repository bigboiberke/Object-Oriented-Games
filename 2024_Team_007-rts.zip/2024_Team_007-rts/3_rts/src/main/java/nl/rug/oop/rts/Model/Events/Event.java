package nl.rug.oop.rts.Model.Events;

import nl.rug.oop.rts.Model.Army.Army;

/**
 * The Event class is an abstract class that represents an event in the game.
 * Subclasses of Event should implement the activate method to specify the behavior of the event.
 */
public abstract class Event {

    /** The name of the event. */
    protected String name;

    /**
     * Constructor for the Event class.
     * Initializes the name of the event.
     *
     * @param name The name of the event.
     */
    public Event(String name) {
        this.name = name;
    }

    /**
     * This method is called to activate the event.
     * Subclasses of Event should implement this method to specify the behavior of the event when it is activated.
     *
     * @param army The army that the event is activated for.
     */
    public abstract void activate(Army army);

    /**
     * Returns the name of the event.
     *
     * @return The name of the event.
     */
    public String getName() {
        return name;
    }
}