package nl.rug.oop.rts;

/**
 * Interface for objects that need to be notified about updates or changes.
 * Classes implementing this should handle how they react to these updates.
 */
public interface TrackerObserver {
    /**
     * Notifies the observer of an update, prompting a reaction such as UI refresh.
     */
    void update();
}