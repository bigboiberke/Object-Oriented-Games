package nl.rug.oop.rts;

import nl.rug.oop.rts.Model.Army.Army;
import nl.rug.oop.rts.Model.Events.Event;

import java.util.List;

/**
 * This interface represents a location that is suitable for an army.
 * It provides methods to add and remove an army from the location.
 */
public interface ArmySuitable {
    /**
     * Adds an army to the location.
     *
     * @param army The army to be added.
     */
    void addArmy(Army army);

    /**
     * Removes an army from the location.
     *
     * @param army The army to be removed.
     */
    void removeArmy(Army army);

    /**
     * Returns the armies on the location.
     *
     * @return The armies on the location.
     */
    List<Army> getArmies();

    /**
     * Returns a random destination from the location.
     *
     * @return A random destination from the location.
     */
    ArmySuitable getRandomDestination();

    /**
     * Adds an event to the location.
     *
     * @param event The event to be added.
     */
    void addEvent(Event event);

    /**
     * Returns the events on the location to be activated on that army.
     *
     * @return The events on the location.
     */
    List<Event> getEvents();

}