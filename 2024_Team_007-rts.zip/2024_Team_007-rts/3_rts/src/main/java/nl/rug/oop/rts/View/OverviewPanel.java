package nl.rug.oop.rts.View;

import nl.rug.oop.rts.Model.Place.Tracker;
import nl.rug.oop.rts.TrackerObserver;
import javax.swing.*;
import java.awt.*;

/**
 * Displays game state overview including nodes, edges, and armies.
 */
public class OverviewPanel extends JPanel implements TrackerObserver {
    private Tracker tracker;
    private JLabel nodesLabel, edgesLabel, armiesLabel, teamOneArmiesLabel, teamTwoArmiesLabel, overviewLabel;

    /**
     * Initializes panel and UI components.
     * @param tracker The game state tracker.
     */
    public OverviewPanel(Tracker tracker) {
        this.tracker = tracker;
        tracker.addObserver(this);
        setBackground(Color.BLACK);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setAlignmentX(Component.CENTER_ALIGNMENT);
        setAlignmentY(Component.CENTER_ALIGNMENT);
        setComponents();
        addComponents();
    }

    /**
     * Sets up labels for displaying game state information.
     */
    private void setComponents(){
        nodesLabel = new JLabel("Nodes: 0");
        edgesLabel = new JLabel("Edges: 0");
        armiesLabel = new JLabel("Armies: 0");
        teamOneArmiesLabel = new JLabel("Team One Armies: 0");
        teamTwoArmiesLabel = new JLabel("Team Two Armies: 0");
        overviewLabel = new JLabel("Overview");
        overviewLabel.setForeground(Color.WHITE);
        overviewLabel.setFont(new Font("Arial", Font.BOLD, 30));
        alignComponents();
    }

    /**
     * Aligns components to the center.
     */
    private void alignComponents() {
        JLabel[] labels = {nodesLabel, edgesLabel, armiesLabel, teamOneArmiesLabel, teamTwoArmiesLabel, overviewLabel};
        for (JLabel label : labels) {
            label.setAlignmentX(Component.CENTER_ALIGNMENT);
        }
    }

    /**
     * Adds UI components to the panel.
     */
    private void addComponents() {
        add(overviewLabel);
        add(nodesLabel);
        add(Box.createRigidArea(new Dimension(0, 10)));
        add(edgesLabel);
        add(Box.createRigidArea(new Dimension(0, 10)));
        add(armiesLabel);
        add(Box.createRigidArea(new Dimension(0, 10)));
        add(teamOneArmiesLabel);
        add(Box.createRigidArea(new Dimension(0, 10)));
        add(teamTwoArmiesLabel);
    }

    /**
     * Updates panel based on tracker state.
     */
    @Override
    public void update() {
        nodesLabel.setText("Nodes: " + tracker.getNodes().size());
        edgesLabel.setText("Edges: " + tracker.getEdges().size());
        armiesLabel.setText("Armies: " + tracker.getArmies().size());
        teamOneArmiesLabel.setText("Team One Armies: " + tracker.getArmiesByTeam(1).size());
        teamTwoArmiesLabel.setText("Team Two Armies: " + tracker.getArmiesByTeam(2).size());
        revalidate();
        repaint();
    }
}