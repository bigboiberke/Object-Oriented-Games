package nl.rug.oop.rts.View;

import lombok.*;
import nl.rug.oop.rts.Controller.*;
import nl.rug.oop.rts.Model.Army.Army;
import nl.rug.oop.rts.Model.Place.Edge;
import nl.rug.oop.rts.Model.Place.Node;
import nl.rug.oop.rts.Model.Place.Tracker;
import nl.rug.oop.rts.TrackerObserver;
import nl.rug.oop.rts.NodeInfoObserver;
import nl.rug.oop.rts.NodeSelectedObserver;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.io.IOException;
import java.util.List;
import java.util.Random;

/**
 * The Panel class extends JPanel and implements UpdateNodeListener.
 * It represents the main panel of the application where nodes and edges are displayed.
 * It also handles user interactions such as adding and removing nodes
 * and edges, and advancing the game by one time step.
 */
public class MapPanel extends JPanel implements NodeInfoObserver, TrackerObserver {
    @Getter
    private Tracker tracker;
    @Setter
    private Point prevPoint;
    @Setter
    private Point currentPoint;
    @Getter
    @Setter
    private boolean isAddingEdge;
    @Getter
    @Setter
    private Node firstNodeForEdge;
    @Getter
    @Setter
    private NodeSelectedObserver nodeSelectedObserver;
    @Getter
    @Setter
    private Simulator simulator;
    private final MouseListener mouseListener;
    private JButton addNode;
    private JButton addEdge;
    private JButton removeNode;
    private JButton removeEdge;
    private JButton nextTimeStep;
    private JButton toJSON;

    /**
     * Constructor for the Panel class.
     * Initializes the tracker, mouseListener, and simulator, and sets up the buttons and mouse listeners.
     *
     * @param tracker The tracker to be displayed on the panel.
     */
    public MapPanel(Tracker tracker) {
        this.tracker = tracker;
        this.prevPoint = new Point(0,0);
        this.currentPoint = new Point(0,0);
        this.mouseListener = new MouseListener(this);
        this.simulator = new Simulator();
        tracker.addObserver(this);
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setPreferredSize(new Dimension(screenSize.width/5, screenSize.height));
        setupButtons();
        setupMouseListeners();
    }

    /**
     * Sets up the mouse listeners for the panel.
     */
    private void setupMouseListeners() {
        MouseMotionListener mouseMotion = new MouseMotionListener();
        addMouseListener(mouseListener);
        addMouseMotionListener(mouseMotion);
    }

    /**
     * Sets up the buttons for the panel.
     */
    private void setupButtons() {
        addNode = createButton("Add Node", e -> {
            TrackerController trackerController = new TrackerController(tracker);
            trackerController.createNode();
        });

        addEdge = createButton("Add Edge", e -> handleAddEdge());
        addEdge.setEnabled(false);

        removeNode = createButton("Remove Node", e -> handleRemoveNode());
        removeNode.setEnabled(false);

        removeEdge = createButton("Remove Edge", e -> handleRemoveEdge());
        removeEdge.setEnabled(false);

        nextTimeStep = createButton("Next Time Step", e -> {
            simulator.forward(tracker);
        });

        toJSON = createButton("Save to JSON", e -> {
            JFileChooser fileChooser = new JFileChooser();
            int userSelection = fileChooser.showSaveDialog(this);
            if (userSelection == JFileChooser.APPROVE_OPTION){
                handleSaveToJSON(fileChooser.getSelectedFile().getAbsolutePath());
            }
        });

        add(addNode);
        add(addEdge);
        add(removeNode);
        add(removeEdge);
        add(nextTimeStep);
        add(toJSON);
    }

    /**
     * Creates a button with the given text and action listener.
     *
     * @param text The text to display on the button.
     * @param actionListener The action listener for the button.
     * @return The created button.
     */
    private JButton createButton(String text, ActionListener actionListener) {
        JButton button = new JButton(text);
        button.addActionListener(actionListener);
        return button;
    }

    /**
     * Handles the action for the addEdge button.
     */
    private void handleAddEdge() {
        if (mouseListener.getSelectedNode() != null) {
            isAddingEdge = true;
            firstNodeForEdge = mouseListener.getSelectedNode();
            mouseListener.setSelectedNode(null);
        }
    }

    /**
     * Handles the action for the removeNode button.
     */
    private void handleRemoveNode() {
        TrackerController trackerController = new TrackerController(tracker);
        trackerController.removeNode(mouseListener.getSelectedNode());
        notifyListener(null);
        removeNode.setEnabled(false);
        mouseListener.setSelectedNode(null);
    }

    /**
     * Handles the action for the removeEdge button.
     */
    private void handleRemoveEdge() {
        if (mouseListener.getSelectedNode() != null) {
            isAddingEdge = false;
            firstNodeForEdge = mouseListener.getSelectedNode();
            mouseListener.setSelectedNode(null);
        }
    }

    /**
     * Handles the action for the save to JSON button.
     *
     * @param path The path to save the JSON file to.
     */
    private void handleSaveToJSON(String path) {
        TrackerController trackerController = new TrackerController(tracker);
        List<String> notWantedFields = List.of("observers", "location", "wasOnNode",
                "isOnNode", "NEXT_ID", "x", "y", "edgesConnected");
        try {
            trackerController.saveToJSON(path, notWantedFields);
        } catch (IllegalAccessException ex) {
            throw new RuntimeException(ex);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    /**
     * Paints the component.
     *
     * @param g The Graphics object to protect.
     */
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Image img = new ImageIcon("src/main/resources/images/maps/mapTexture.jpg").getImage();
        g.drawImage(img, 0, 0, this);
        drawGraph(g);
    }

    /**
     * Draws the graph on the panel.
     *
     * @param g The Graphics object to protect.
     */
    private void drawGraph(Graphics g){
        if (tracker.getNodes().isEmpty()) {
            return;
        }
        drawEdges(g);
        drawNodes(g);
    }

    /**
     * Draws the edges on the panel.
     *
     * @param g The Graphics object to protect.
     */
    private void drawEdges(Graphics g){
        Stroke dashed = new BasicStroke(3, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[]{9}, 0);
        ((Graphics2D) g).setStroke(dashed);
        Random random = new Random();
        for (Edge edge : tracker.getEdges()) {
            g.setColor(Color.black);
            g.drawLine(edge.getStartNode().getX()+25, edge.getStartNode().getY()+25,
                    edge.getEndNode().getX()+25, edge.getEndNode().getY()+25);
            for(Army army : edge.getArmies()){
                g.setColor(army.getFaction().getColor());
                g.fillOval((edge.getStartNode().getX() + edge.getEndNode().getX() + random.nextInt(30))/2,
                        (edge.getStartNode().getY() + edge.getEndNode().getY() + random.nextInt(30))/2, 8, 8);
            }
        }
    }

    /**
     * Draws the nodes on the panel.
     *
     * @param g The Graphics object to protect.
     */
    private void drawNodes(Graphics g){
        Random random = new Random();

        for (Node node : tracker.getNodes()) {
            Image img = new ImageIcon("src/main/resources/images/nodes/node3.png").getImage();
            if ( node.equals(mouseListener.getSelectedNode()) ) {
                node.setCoordinates(currentPoint);
                img = new ImageIcon("src/main/resources/images/nodes/node4.png").getImage();
                updateButtonState(true);
            }
            g.drawImage(img, node.getX(), node.getY(), 75, 75, this);
            for (Army army : node.getArmies()) {
                g.setColor(army.getFaction().getColor());
                g.fillOval(node.getX() + random.nextInt(35)+20, node.getY() + random.nextInt(35)+20, 8, 8);
            }
            g.setColor(Color.black);
            g.drawString(node.getName(), node.getX()+20, node.getY()+40);
        }
    }

    /**
     * Updates the state of the buttons.
     *
     * @param status The new status of the buttons.
     */
    public void updateButtonState(boolean status){
        this.addEdge.setEnabled(status);
        this.removeNode.setEnabled(status);
        this.removeEdge.setEnabled(status);
    }

    /**
     * Updates the observer with the selected node.
     *
     * @param node The selected node.
     */
    public void notifyListener(Node node) {
        nodeSelectedObserver.nodeSelected(node);
    }

    /**
     * Refreshes the panel.
     */
    public void update(){
        revalidate();
        repaint();
    }

    /**
     * Resets UI and selections when clicking outside nodes/edges.
     */
    public void clickedOnNothing() {
        updateButtonState(false);
        setAddingEdge(false);
        setFirstNodeForEdge(null);
        repaint();
    }

    /**
     * The MouseMotionListener class extends MouseMotionAdapter to handle mouse motion events.
     */
    private class MouseMotionListener extends MouseMotionAdapter {
        /**
         * Handles mouse dragged event.
         *
         * @param e The mouse event.
         */
        @Override
        public void mouseDragged(MouseEvent e) {
            currentPoint.translate(
                    (int) (e.getX() - prevPoint.getX()),
                    (int) (e.getY() - prevPoint.getY())
            );
            prevPoint = e.getPoint();
            repaint();
        }
    }
}