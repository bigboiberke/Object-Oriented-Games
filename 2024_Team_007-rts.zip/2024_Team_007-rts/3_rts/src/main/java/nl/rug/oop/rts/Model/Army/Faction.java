package nl.rug.oop.rts.Model.Army;

import lombok.Getter;
import java.awt.*;
import java.util.Random;

/**
 * This enum represents the different factions in the game.
 * Each faction has a set of units and a color associated with it.
 */
public enum Faction {
    MEN(Units.MEN_UNITS, Color.RED),
    ELVES(Units.ELVES_UNITS, Color.YELLOW),
    DWARVES(Units.DWARVES_UNITS, Color.ORANGE),
    MORDOR(Units.MORDOR_UNITS, Color.BLACK),
    ISENGARD(Units.ISENGARD_UNITS, Color.GREEN);

    // Array of units belonging to this faction
    private final Units[] units;
    // Color associated with this faction
    @Getter
    private final Color color;

    /**
     * Constructs a new Faction with the given units and color.
     *
     * @param units The units of the faction.
     * @param color The color of the faction.
     */
    Faction(Units[] units, Color color) {
        this.units = units;
        this.color = color;
    }

    /**
     * Overrides the toString method to return the name of the faction.
     *
     * @return The name of the faction.
     */
    @Override
    public String toString() {
        return name();
    }

    /**
     * Returns a random unit from this faction.
     *
     * @return A random unit from this faction.
     */
    public Units getRandomUnit() {
        Random random = new Random();
        return units[random.nextInt(units.length)];
    }

    /**
     * This enum represents the different units in the game.
     * Each unit has a name, health, and damage associated with it.
     */
    public enum Units {
        // MEN units
        GONDOR_SOLDIER("Gondor Soldier", 100, 20),
        TOWER_GUARD("Tower Guard", 120, 15),
        ITHILIEN_RANGER("Ithilien Ranger", 80, 25),

        // ELVES units
        LORIEN_WARRIOR("Lorien Warrior", 90, 30),
        MIRKWOOD_ARCHER("Mirkwood Archer", 70, 35),
        RIVENDELL_LANCER("Rivendell Lancer", 110, 20),

        // DWARVES units
        DWARVES_GUARDIAN("Guardian", 130, 15),
        DWARVES_PHALANX("Phalanx", 120, 20),
        DWARVES_AXE_THROWER("Axe Thrower", 80, 30),

        // MORDOR units
        ORC_WARRIOR("Orc Warrior", 100, 20),
        ORC_PIKEMAN("Orc Pikeman", 110, 15),
        HARADRIM_ARCHER("Haradrim Archer", 70, 35),

        // ISENGARD units
        URUK_HAI("Uruk-hai", 120, 20),
        URUK_CROSSBOWMAN("Uruk Crossbowman", 80, 30),
        WARG_RIDER("Warg Rider", 100, 25);

        // Arrays of units for each faction
        static final Units[] MEN_UNITS = {GONDOR_SOLDIER, TOWER_GUARD, ITHILIEN_RANGER};
        static final Units[] ELVES_UNITS = {LORIEN_WARRIOR, MIRKWOOD_ARCHER, RIVENDELL_LANCER};
        static final Units[] DWARVES_UNITS = {DWARVES_GUARDIAN, DWARVES_PHALANX, DWARVES_AXE_THROWER};
        static final Units[] MORDOR_UNITS = {ORC_WARRIOR, ORC_PIKEMAN, HARADRIM_ARCHER};
        static final Units[] ISENGARD_UNITS = {URUK_HAI, URUK_CROSSBOWMAN, WARG_RIDER};

        // Name of the unit
        @Getter
        private final String name;
        // Health of the unit
        @Getter
        private int health;
        // Damage of the unit
        @Getter
        private int damage;

        /**
         * Constructs a new Unit with the given name, health, and damage.
         *
         * @param name The name of the unit.
         * @param health The health of the unit.
         * @param damage The damage of the unit.
         */
        Units(String name, int health, int damage) {
            this.name = name;
            this.health = health;
            this.damage = damage;
        }
    }
}