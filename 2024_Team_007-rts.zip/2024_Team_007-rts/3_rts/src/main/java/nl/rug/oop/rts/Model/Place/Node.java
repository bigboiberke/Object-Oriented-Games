package nl.rug.oop.rts.Model.Place;

import lombok.Getter;
import lombok.Setter;
import nl.rug.oop.rts.ArmySuitable;
import nl.rug.oop.rts.Controller.LocationController;
import nl.rug.oop.rts.Model.Army.Army;
import nl.rug.oop.rts.Model.Events.Event;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;

/**
 * The Node class represents a node in the game.
 * It implements the SuitableForArmy interface, indicating that an army can be placed on it.
 * Each node has a unique ID, a name, coordinates (x, y), a list of edges
 * connected to it, a list of armies on it, and a list of events associated with it.
 */
public class Node implements ArmySuitable {
    static final AtomicLong NEXT_ID = new AtomicLong(0);
    @Getter
    private final long id = NEXT_ID.getAndIncrement();
    @Setter
    @Getter
    private String name;
    @Getter
    private int x;
    @Getter
    private int y;
    @Getter
    private List<Edge> edgesConnected;
    @Getter
    private List<Army> armies;
    @Getter
    private List<Event> events;

    /**
     * Constructor for the Node class.
     * Initializes the node with the given coordinates, and creates empty lists for edges, armies, and events.
     * Also creates a LocationController for the node and adds events to it.
     *
     * @param x The x-coordinate of the node.
     * @param y The y-coordinate of the node.
     */
    public Node(int x, int y) {
        this.name = "Node " + id;
        this.x = x;
        this.y = y;
        this.edgesConnected = new ArrayList<>();
        this.armies = new ArrayList<>();
        this.events = new ArrayList<>();
        LocationController locationController = new LocationController(this);
        locationController.addEvents(this);
    }

    /**
     * Adds an edge to the list of edges connected to the node.
     *
     * @param edge The edge to be added.
     */
    public void addEdge(Edge edge) {
        this.edgesConnected.add(edge);
    }

    /**
     * Adds an army to the list of armies on the node.
     *
     * @param army The army to be added.
     */
    public void addArmy(Army army) {
        this.armies.add(army);
    }

    /**
     * Removes an edge from the list of edges connected to the node.
     *
     * @param edge The edge to be removed.
     */
    public void removeEdge(Edge edge) {
        this.edgesConnected.remove(edge);
    }

    /**
     * Returns a random edge from the list of edges connected to the node.
     *
     * @return A random edge.
     */
    public Edge getRandomDestination() {
        Random random = new Random();
        return edgesConnected.get(random.nextInt(edgesConnected.size()));
    }

    /**
     * Removes an army from the list of armies on the node.
     *
     * @param army The army to be removed.
     */
    public void removeArmy(Army army) {
        this.armies.remove(army);
    }

    /**
     * Sets the coordinates of the node.
     *
     * @param point A Point object containing the new coordinates.
     */
    public void setCoordinates(Point point) {
        this.x = point.x;
        this.y = point.y;
    }

    /**
     * Adds an event to the list of events on the node.
     *
     * @param event The event to be added.
     */
    public void addEvent(Event event) {
        this.events.add(event);
    }
}