package nl.rug.oop.rts.View;

import nl.rug.oop.rts.Controller.LocationController;
import nl.rug.oop.rts.Controller.TrackerController;
import nl.rug.oop.rts.Model.Army.Army;
import nl.rug.oop.rts.Model.Army.Faction;
import nl.rug.oop.rts.Model.Events.Event;
import nl.rug.oop.rts.Model.Place.Node;
import nl.rug.oop.rts.Model.Place.Tracker;
import nl.rug.oop.rts.NodeSelectedObserver;
import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

/**
 * This class represents an options panel in the application.
 * It extends JPanel and implements SelectedNodeListener interface.
 * It contains various UI components and methods to handle node selection events.
 */
public class OptionsPanel extends JPanel implements NodeSelectedObserver {
    // UI components and other attributes
    private Node currentNode;
    private Tracker tracker;
    private JButton confirmButton;
    private JButton removeArmyButton;
    private JButton addArmyButton;
    private JLabel nameLabel;
    private JLabel armyLabel;
    private JLabel eventLabel;
    private JPanel armyPanel;
    private JPanel eventPanel;
    private JTextField nameTextField;
    private ButtonGroup armyGroup;
    private JComboBox<Faction> factionComboBox;
    private Map<JCheckBox, Army> armyMap;

    /**
     * Constructs a new OptionsPanel.
     * Initializes the UI components and sets their action listeners.
     *
     * @param tracker The tracker to use for the OptionsPanel.
     */
    public OptionsPanel(Tracker tracker) {
        this.tracker = tracker;
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setBackground(Color.BLACK);
        setPreferredSize(new Dimension(screenSize.width / 5, screenSize.height));
        setComponents();
        setActionListeners();
    }

    /**
     * Creates a JLabel with the specified properties.
     *
     * @param text The text to display on the label.
     * @param fontStyle The style of the font to use for the label.
     * @param fontSize The size of the font to use for the label.
     * @param isVisible Whether the label should be visible.
     * @return The created JLabel.
     */
    private JLabel createLabel(String text, int fontStyle, int fontSize, boolean isVisible) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", fontStyle, fontSize));
        label.setVisible(isVisible);
        return label;
    }

    /**
     * Creates a JButton with the specified properties.
     *
     * @param text The text to display on the button.
     * @param isVisible Whether the button should be visible.
     * @return The created JButton.
     */
    private JButton createButton(String text, boolean isVisible) {
        JButton button = new JButton(text);
        button.setPreferredSize(new Dimension(240, 30));
        button.setVisible(isVisible);
        return button;
    }

    /**
     * Creates a JTextField with the specified properties.
     *
     * @param text The text to display in the text field.
     * @param isEnabled Whether the text field should be enabled.
     * @return The created JTextField.
     */
    private JTextField createTextField(String text, boolean isEnabled) {
        JTextField textField = new JTextField(text);
        textField.setPreferredSize(new Dimension(100, 30));
        textField.setEnabled(isEnabled);
        return textField;
    }

    /**
     * Sets up the UI components for the OptionsPanel.
     */
    private void setComponents() {
        nameLabel = createLabel("Name: ", Font.PLAIN, 20, false);
        armyLabel = createLabel("Armies: ", Font.BOLD, 25, false);
        confirmButton = createButton("Confirm", false);
        addArmyButton = createButton("Add Army", false);
        removeArmyButton = createButton("Remove Army", false);
        nameTextField = createTextField("WoW it's so empty here!", false);
        armyPanel = new JPanel();
        armyPanel.setLayout(new BoxLayout(armyPanel, BoxLayout.Y_AXIS));
        armyGroup = new ButtonGroup();
        armyMap = new HashMap<>();
        eventPanel = new JPanel();
        eventPanel.setLayout(new BoxLayout(eventPanel, BoxLayout.Y_AXIS));
        eventPanel.setBackground(Color.BLACK);
        eventLabel = createLabel("Events: ", Font.BOLD, 25, false);
        factionComboBox = new JComboBox<>(Faction.values());
        factionComboBox.setPreferredSize(new Dimension(100, 30));
        factionComboBox.setVisible(false);
        addComponents();
    }

    /**
     * Adds the UI components to the OptionsPanel.
     */
    private void addComponents() {
        add(nameLabel);
        add(nameTextField);
        add(confirmButton);
        add(armyLabel);
        add(factionComboBox);
        add(addArmyButton);
        add(armyPanel);
        add(removeArmyButton);
        add(eventLabel);
        add(eventPanel);
    }

    /**
     * Sets up the action listeners for the UI components.
     */
    private void setActionListeners() {
        confirmButton.addActionListener(e -> {
            currentNode.setName(nameTextField.getText());
            nodeSelected(currentNode); // refresh the panel
            notifyObservers();
        });

        addArmyButton.addActionListener(e -> {
            LocationController nodeListener = new LocationController(currentNode);
            nodeListener.addArmyOfFaction((Faction) factionComboBox.getSelectedItem());
            nodeSelected(currentNode); // refresh the panel
            notifyObservers();
        });

        removeArmyButton.addActionListener(e -> {
            for (Map.Entry<JCheckBox, Army> entry : armyMap.entrySet()) {
                if (entry.getKey().isSelected()) {
                    LocationController nodeListener = new LocationController(currentNode);
                    nodeListener.removeArmy(entry.getValue());
                    notifyObservers();
                    break;
                }
            }
            nodeSelected(currentNode); // refresh the panel
        });
    }

    /**
     * Handles the event when a node is selected.
     *
     * @param node The selected node.
     */
    public void nodeSelected(Node node) {
        if (node == null) {
            updateUIComponents(false, "SELECT. SOMETHING. NOW.");
            return;
        }
        updateUIComponents(true, node.getName());
        armyPanel.removeAll();
        armyGroup = new ButtonGroup();
        armyMap.clear();
        currentNode = node;
        for (Army army : node.getArmies()) {
            JCheckBox checkBox = new JCheckBox(army.getName() + " " + army.getUnits().size());
            armyGroup.add(checkBox);
            armyPanel.add(checkBox);
            armyMap.put(checkBox, army);
        }
        armyPanel.revalidate();
        armyPanel.repaint();
        eventPanel.removeAll();
        for (Event event : node.getEvents()) {
            JLabel eventName = new JLabel(event.getName());
            eventName.setFont(new Font("Arial", Font.BOLD, 15));
            eventPanel.add(eventName);
        }
        eventPanel.revalidate();
        eventPanel.repaint();
    }

    /**
     * Updates the UI components with the specified status and text.
     *
     * @param status The status to update the UI components with.
     * @param text The text to update the UI components with.
     */
    private void updateUIComponents(boolean status, String text) {
        nameLabel.setVisible(status);
        armyLabel.setVisible(status);
        addArmyButton.setVisible(status);
        confirmButton.setVisible(status);
        factionComboBox.setVisible(status);
        removeArmyButton.setVisible(status);
        nameTextField.setEnabled(status);
        nameTextField.setText(text);
        eventLabel.setVisible(status);
        armyPanel.setVisible(status);
        eventPanel.setVisible(status);

    }

    /**
     * Updates the observers of the OptionsPanel.
     */
    private void notifyObservers() {
        TrackerController trackerController = new TrackerController(tracker);
        trackerController.updateObservers();
    }
}