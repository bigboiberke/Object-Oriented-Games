package nl.rug.oop.rts.Model.Events;

import lombok.Getter;

/**
 * The EventEnum class is an enumeration of the different types of events in the game.
 * Each event type is associated with an instance of a subclass of Event.
 */
public enum EventEnum {
    /**
     * The REINFORCEMENTS event type, associated with an instance of the ReinforcementsEvent class.
     */
    REINFORCEMENTS(new ReinforcementsEvent()),

    /**
     * The HEALING_RAIN event type, associated with an instance of the HealingRainEvent class.
     */
    HEALING_RAIN(new HealingRainEvent()),

    /**
     * The STORM event type, associated with an instance of the StormEvent class.
     */
    STORM(new StormEvent()),

    /**
     * The DUPLICATE_ARMY event type, associated with an instance of the DuplicateArmyEvent class.
     */
    DUPLICATE_ARMY(new DuplicateArmyEvent());

    /**
     * The Event associated with the event type.
     */
    @Getter
    private final Event event;

    /**
     * Constructor for the EventEnum class.
     *
     * @param event The Event associated with the event type.
     */
    EventEnum(Event event){
        this.event = event;
    }
}