package nl.rug.oop.rts.Model.Events;

import nl.rug.oop.rts.Model.Army.Army;
import nl.rug.oop.rts.Model.Army.Unit;

/**
 * The ReinforcementsEvent class represents a reinforcements event in the game.
 * It extends the Event class and overrides the activate method to add new units to an army.
 */
public class ReinforcementsEvent extends Event{

    /**
     * Constructor for the ReinforcementsEvent class.
     * Initializes the name of the event.
     */
    public ReinforcementsEvent() {
        super("Reinforcements");
    }

    /**
     * Activates the reinforcements event for a specified army.
     * Adds 5 new units to the army.
     *
     * @param army The army that the event is activated for.
     */
    @Override
    public void activate(Army army) {
        for (int i = 0; i < 5; i++) {
            army.addUnit(new Unit(army.getFaction()));
        }
    }
}
