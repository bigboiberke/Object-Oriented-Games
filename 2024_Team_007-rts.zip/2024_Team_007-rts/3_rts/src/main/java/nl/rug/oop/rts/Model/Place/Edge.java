package nl.rug.oop.rts.Model.Place;

import lombok.Getter;
import nl.rug.oop.rts.ArmySuitable;
import nl.rug.oop.rts.Controller.LocationController;
import nl.rug.oop.rts.Model.Army.Army;
import nl.rug.oop.rts.Model.Events.Event;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;

/**
 * The Edge class represents an edge in a graph, connecting two Node objects.
 * It implements the SuitableForArmy interface, meaning it can host Army objects.
 * Each Edge has a unique ID, a name, a start Node, an end Node, a list of Army objects, and a list of Event objects.
 */
public class Edge implements ArmySuitable {
    static final AtomicLong NEXT_ID = new AtomicLong(0);
    @Getter
    private final long id = NEXT_ID.getAndIncrement();
    @Getter
    private String name;
    @Getter
    private Node startNode;
    @Getter
    private Node endNode;
    @Getter
    private List<Army> armies;
    @Getter
    private List<Event> events;

    /**
     * Constructs a new Edge with the given start and end Nodes.
     * Initializes the name, armies list, and events list.
     * Adds the Edge to the start and end Nodes.
     *
     * @param startNode The start Node of the Edge.
     * @param endNode The end Node of the Edge.
     */
    public Edge(Node startNode, Node endNode){
        this.name = "Edge " + id;
        this.startNode = startNode;
        this.endNode = endNode;
        this.armies = new ArrayList<>();
        this.events = new ArrayList<>();
        LocationController locationController = new LocationController(this);
        locationController.addEvents(this);
        startNode.addEdge(this);
        endNode.addEdge(this);
    }

    /**
     * Adds the given Army to the list of armies on this Edge.
     *
     * @param army The Army to add.
     */
    public void addArmy(Army army) {
        this.armies.add(army);
    }

    /**
     * Removes the given Army from the list of armies on this Edge.
     *
     * @param army The Army to remove.
     */
    public void removeArmy(Army army) {
        this.armies.remove(army);
    }

    /**
     * Returns a random Node connected to this Edge (either the start or end Node).
     *
     * @return A random Node connected to this Edge.
     */
    public Node getRandomDestination() {
        Random random = new Random();
        if (random.nextInt(2) == 1){
            return startNode;
        } else {
            return endNode;
        }
    }

    /**
     * Adds the given Event to the list of events on this Edge.
     *
     * @param event The Event to add.
     */
    public void addEvent(Event event) {
        this.events.add(event);
    }
}