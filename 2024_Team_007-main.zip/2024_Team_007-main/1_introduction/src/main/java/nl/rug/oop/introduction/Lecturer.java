package nl.rug.oop.introduction;

import java.util.List;

/**
 * The Lecturer class represents a lecturer who gives lectures to students.
 */
public class Lecturer {
    private String name;  // The name of the lecturer.

    /**
     * Constructs a new Lecturer object.
     *
     * @param name The name of the lecturer.
     */
    public Lecturer(String name) {
        this.name = name;
    }

    /**
     * Gives a lecture to a list of students.
     * Each student in the list obtains knowledge from the lecture.
     *
     * @param attendees The list of students attending the lecture.
     */
    public void lecture(List<Student> attendees) {
        System.out.println("Try adapting to this lecture.");
        for (Student student : attendees) {
            student.obtainKnowledge();
        }
    }
}