package nl.rug.oop.introduction;

import java.time.LocalDateTime;

/**
 * The Submission class represents a student's submission for an assignment.
 */
public class Submission {

    private int quality;  // The quality of the submission, represented as an integer.
    private final LocalDateTime submissionDate;  // The date and time when the submission was made.
    private String studentName;  // The name of the student who made the submission.
    private String assignmentName;  // The name of the assignment for which the submission was made.

    /**
     * Constructs a new Submission object.
     *
     * @param student    The student who is making the submission.
     * @param assignment The assignment for which the submission is being made.
     */
    public Submission(Student student, Assignment assignment) {
        this.studentName = student.getName();
        this.assignmentName = assignment.getAssignmentName();
        this.submissionDate = LocalDateTime.now();
        quality = student.getKnowledgeLevel();
    }

    /**
     * Returns the date and time when the submission was made.
     *
     * @return A LocalDateTime object representing the date and time of the submission.
     */
    public LocalDateTime getSubmissionDate() {
        return submissionDate;
    }

    /**
     * Returns the name of the student who made the submission.
     *
     * @return A String representing the student's name.
     */
    public String getStudentName() {
        return studentName;
    }

    /**
     * Returns the quality of the submission.
     *
     * @return An integer representing the quality of the submission.
     */
    public int getQuality() {
        return quality;
    }

    /**
     * Returns the name of the assignment for which the submission was made.
     *
     * @return A String representing the name of the assignment.
     */
    public String getSubmissionAssignmentName() {
        return assignmentName;
    }
}