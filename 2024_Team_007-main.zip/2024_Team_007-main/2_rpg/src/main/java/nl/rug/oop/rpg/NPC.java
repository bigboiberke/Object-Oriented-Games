package nl.rug.oop.rpg;

import java.io.Serializable;

/**
 * The NPC class represents a non-player character in the game.
 * It implements the Inspectable and Interactable.
 * An NPC has a description, health, damage, and type.
 */
public abstract class NPC implements Inspectable, Interactable, Serializable {
    private String description;
    private int health;
    private int damage;
    private static final long serialVersionUID = 1L;

    /**
     * Constructor for the NPC class.
     *
     * @param description The description of the NPC.
     * @param health The health of the NPC.
     * @param damage The damage of the NPC.
     */
    public NPC(String description, int health, int damage){
        this.description = description;
        this.health = health;
        this.damage = damage;
    }

    /**
     * Returns the damage of the NPC.
     *
     * @return The damage of the NPC.
     */
    public int getDamage(){
        return this.damage;
    }

    /**
     * Returns the health of the NPC.
     *
     * @return The health of the NPC.
     */
    public int getHealth(){
        return this.health;
    }

    /**
     * Updates the health of the NPC.
     *
     * @param health The new health value for the NPC.
     */
    public void updateHealth(int health){
        this.health = health;
    }

    /**
     * Prints the description of the NPC.
     */
    public void inspect(){
        System.out.println(this.description);
    }

    /**
     * Interacts with the player.
     * If the NPC is an enemy, it starts a battle with the player.
     * Otherwise, it talks to the player.
     *
     * @param player The player character.
     */
    public void interact(Player player){
        System.out.println("You talk to the NPC.");
    }
}