package nl.rug.oop.rpg;

/**
 * The InteractableInterface interface provides a method for interacting with an object.
 * This interface is implemented by classes that represent objects that can interact with a player.
 */
public interface Interactable{
    /**
     * Interacts with the player.
     * The implementation of this method should define the interaction between the object and the player.
     *
     * @param player The player character.
     */
    void interact(Player player);
}