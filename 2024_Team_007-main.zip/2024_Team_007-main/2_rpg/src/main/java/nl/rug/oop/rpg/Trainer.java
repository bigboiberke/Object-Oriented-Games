package nl.rug.oop.rpg;

import java.io.Serializable;
import java.util.Scanner;

/**
 * The Trainer class represents a trainer NPC in the game.
 * The trainer can train the player to increase their damage for a cost.
 */
public class Trainer extends NPC implements Serializable {
    private static final long serialVersionUID = 1L;
    /**
     * Constructs a new Trainer with the given name, damage, and health.
     *
     * @param name The name of the trainer.
     * @param damage The damage that the trainer can inflict.
     * @param health The health of the trainer.
     */

    public Trainer(String name, int damage, int health){
        super(name, damage, health);
    }

    /**
     * This method handles the interaction between the player and the trainer.
     * The trainer offers to train the player to increase their damage for 10 coins.
     * If the player agrees and has enough money, the trainer trains the player.
     * If the player does not have enough money, the trainer informs them of this.
     *
     * @param player The player character.
     */
    @Override
    public void interact(Player player){
        System.out.println("Trainer Tom: I can train you to increase your damage for 10 coins." +
                " Do you want to? (To train type yes)");
        Scanner scanner = new Scanner(System.in);
        String choice = scanner.nextLine();
        if (choice.equals("yes")){
            if (player.getMoney() >= 10){
                player.updateMoney(player.getMoney() - 10);
                this.trainPlayer(player);
            } else {
                System.out.println("Trainer Tom: You don't have enough gold, sorry.");
            }
        }
    }

    /**
     * Trains the player to increase their damage.
     * The method simulates the training process by printing a series of dots over a period of time.
     * After the training is completed, the player's damage is increased by 2.
     *
     * @param player The player character.
     */
    public void trainPlayer(Player player){
        Timer timer = new Timer();
        System.out.print("Training ");
        // Simulate the training process by printing a series of dots over a period of time
        for (int i = 1; i <= 10; i++) {
            System.out.print("● ");
            timer.stopTime(1000);
        }
        // Increase the player's damage by 2
        player.updateDamage(player.getDamage() + 2);
        System.out.println("\nTraining has been completed!");
    }
}
