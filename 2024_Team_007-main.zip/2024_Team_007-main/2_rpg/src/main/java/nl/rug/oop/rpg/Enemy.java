package nl.rug.oop.rpg;

import java.io.Serializable;
import java.util.Random;
import java.util.Scanner;

/**
 * The Enemy class represents an enemy NPC in the game.
 * This class extends the NPC class and implements the Serializable and Damageable interfaces.
 * An enemy can inflict damage and also take damage.
 * When an enemy is defeated, it drops a certain amount of money.
 */
public class Enemy extends NPC implements Serializable, Damageable{
    /**
     * The amount of money that the enemy will drop when defeated.
     */
    private int moneyWhenKilled;

    private int xpWhenKilled;

    /**
     * The serialVersionUID is a universal version identifier for a Serializable class.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Constructs a new Enemy with the given name, damage, and health.
     * Additionally, it assigns a random amount of money (between 1 and 5) that the enemy will drop when defeated.
     *
     * @param description The description of the enemy.
     * @param damage The damage that the enemy can inflict.
     * @param health The health of the enemy.
     */
    public Enemy(String description, int damage, int health){
        super(description, damage, health);
        Random random = new Random();
        this.moneyWhenKilled = random.nextInt(5)+1;
        this.xpWhenKilled = random.nextInt(5)+1;
    }

    /**
     * This method is used to inspect the enemy.
     * It prints out the current health and damage of the enemy.
     */

    @Override
    public void inspect(){
        System.out.println("An enemy with " + this.getHealth() + " health and " + this.getDamage() + " damage.");
    }

    /**
     * Starts a battle with the player.
     * The player and the enemy take turns attacking each other until one of them has no health left.
     * The player has the option to run away from the battle.
     *
     * @param player The player character.
     */

    @Override
    public void interact(Player player){
        Scanner scanner = new Scanner(System.in);
        System.out.println("You have encountered an enemy. Do you want to attack? (-1 to run)");

        while(this.getHealth() > 0 && player.getHealth() > 0){
            String choice = scanner.next();
            if (choice.equals("-1")){
                System.out.println("You ran away.");
                break;
            }

            this.attack(player);
            player.attack(this);

            System.out.println(
                "You exechanged blows. " +
                "Your health: " + player.getHealth() +
                " Enemy health: " + this.getHealth()
            );

            if (this.getHealth() <= 0){
                enemyDefeated(player);
            }
        }
    }

    /**
     * Attacks the player by reducing the player's health by the enemy's damage.
     *
     * @param player The player character.
     */
    public void attack(Player player){
        player.takeDamage(this.getDamage());
    }

    /**
     * Updates the health of the enemy by reducing it by a specified amount of damage.
     *
     * @param damage The amount of damage to inflict on the enemy.
     */
    public void takeDamage(int damage){
        this.updateHealth(this.getHealth()-damage);
    }

    /**
     * Handles the event of the enemy being defeated by the player.
     * The player receives a random amount of money from the enemy.
     * Then, the enemy is removed from the room.
     *
     * @param player The player character.
     */
    public void enemyDefeated(Player player) {
        System.out.println(
            "You have defeated an enemy." +
            "\nRewards: " +
            "\nExperience: " + this.xpWhenKilled +
            "\nMoney: " + this.moneyWhenKilled
        );
        Timer timer = new Timer();
        timer.stopTime(2000);
        player.monsterDefeated(this.xpWhenKilled, this.moneyWhenKilled);
    }
}