package nl.rug.oop.rpg;

import java.io.Serializable;

/**
 * The Item class represents an item in the game.
 * Each item has a name and a value.
 */
public class Item implements Serializable {
    private String name;
    private int value;
    private static final long serialVersionUID = 1L;

    /**
     * Constructs a new Item with the given name and value.
     *
     * @param name The name of the item.
     * @param value The value of the item.
     */
    public Item(String name, int value){
        this.name = name;
        this.value = value;
    }

    /**
     * Returns the name of the item.
     *
     * @return The name of the item.
     */
    public String getName(){
        return name;
    }

    /**
     * Returns the value of the item.
     *
     * @return The value of the item.
     */
    public int getValue(){
        return value;
    }
}