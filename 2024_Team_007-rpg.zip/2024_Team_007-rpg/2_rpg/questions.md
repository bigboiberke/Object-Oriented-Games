# Question 1

In step 1, you were asked to create a `Room` class with a description, which will be printed if inspected. Two software 
developers proposed two different implementations for the `Room` class.

The first developer proposed one implementation:

```java
public class Room {

    private String description;

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
```

The second developer proposed another implementation:

```java
public class Room {
    public String description;
}
```

Both developers are discussing which implementation is better and why. Please answer the following question:

Which of these two implementations would you select? And why?

Justify your answer in at least 250 words. Please explain the consequences, benefits and drawbacks of each 
implementation and support it with an example.

___

Answer:

The first implementation takes advantage of the encapsulation concept in OOP. This is a fundamental concept that
whatever happens inside of this method is hidden from the rest of the program. There are several advantages to using
this kind of method:

Firstly, we can assume control over data by using things like setter and getter functions, which will help us have
full control over how the “description” is accessed and modified.

Secondly, we are able to modify the method internally, meaning that our internal changes won’t have an effect on the
rest of the code and will help us avoid confusion in the future. The only thing that needs to be done after such
changes will be to update the getter and setter if the storage mechanism for description is changed, while the rest
of the code remains the same.

Finally, there are also minor drawbacks to using an encapsulation based method while creating a project.
The biggest one would be the fact that this kind of method requires more lines of code compared to the second method
which we will talk about soon.

The second implementation is the complete opposite of the first one as it makes the description field public and be
accessible by the entire codebase. This approach is certainly shorter and simples compared to the first one, but it
also has many more drawbacks at the same time:
Firstly we lack control, meaning that there is no way to enforce constraints or perform validation on the “description”
field. The entire code has access to this field, meaning that any changes may cause to future issues that will make the
code not work properly.

Secondly, this method lacks flexibility compared to the first one. When a change is made in the method, this means
that the developer must go through all uses of the method and update the according to the changes made in the initial
method, which makes it easier for the developer to miss something that will lead to an eventual error.
In conclusion, I believe that sacrificing having a shorter code is worth it in this case as the longer version that
makes use of encapsulation is a lot more effective.

Imagine a future requirement where the description needs to be logged every time it is changed. With the first
implementation, you can simply add logging in the setter method, while in the second implementation, you would need
to add logging wherever the description is modified, which is cumbersome and prone to errors.


___

# Question 2

In step 2, you are asked to create two interfaces: `Inspectable` and `Interactable`.
Interfaces by definition do not have implementations. They consist of method signatures:

```java
interface Inspectable {
void inspect();
}
```

A software developer claims that interfaces are not useful, because they do not contain implementations. Thus,
we should just use classes, and we do not need to define empty interfaces.

What do you think about this opinion? Do you agree or disagree with this opinion?

Please justify your answer in at least 250 words, and support your justifications with an example.

___

Answer:
I personally do not agree with the statement that interfaces are not useful as they help the developer in creating and
maintaining flexible and maintainable software systems. There are many reasons as to why this is the case:

Firstly, using interfaces helps us create a contractual design, which means that all classes that implements the
certain interface must adhere to its constraints. This ensures a consistent set of methods that can be expected from
any class implementing the interface. In our example, the Inspectable and Interactable interfaces create constraints
that are only implemented by objects that the user interacts with or inspects.

Secondly, interfaces decouple the definition of a method from its implementation. This promotes loose coupling and
enhances flexibility, allowing different implementations to be swapped easily without changing the code that depends
on the interface.

In our implementation, both Room and Item can be inspected, but the actual implementation of inspect() may vary. The
code that uses Inspectable objects does not need to know the specifics of these implementations, only that it can
call inspect().

Thirdly, the use of interfaces allows us to be enable polymorphism, which allows one interface to be used for a
general class of actions. For instance, it is especially useful in collections and APIs that work with multiple types:

```java
List<Inspectable> inspectables = new ArrayList<>();
inspectables.add(new Room());
        inspectables.add(new Item());

        for (Inspectable i : inspectables) {
        i.inspect();
}
```

In this example, we can store different types of Inspectable objects in the same list and treat them uniformly.
This simplifies code and makes it more generic.

___

# Question 3

To save your game state, you were asked to use Java classes `FileOutputStream` and `ObjectOutputStream`.
These two classes are part of the Java libraries, and they are designed based on a specific design pattern.

Which design pattern do `FileOutputStream` and `ObjectOutputStream` implement?

Explain the roles of this design pattern and how `FileOutputStream` and `ObjectOutputStream` implement it. Also explain 
the benefit of implementing this design pattern.

___

Answer:

The FileOutputSteam and ObjectOutputStream functions are used to implement the thing called Decorator design pattern.
This is a way in which the developer can implement dynamic addition of responsibilities to objects without having the
need to change their structure.

FileOutputStream essentially writes raw bytes to a file, while ObjectOutputStream, gives them functionality through
the serialization of objects.

The benefit of utilizing FileOutputStream and ObjectOutputStream is mostly for the sake of reusability.


___
