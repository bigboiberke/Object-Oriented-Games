package nl.rug.oop.rpg;

import java.io.Serializable;
import java.util.Scanner;

/**
 * The WiseDoor class represents a door with a puzzle in the game.
 * It extends the Door class and implements the Serializable interface.
 * A WiseDoor can be open by solving a puzzle.
 */
public class WiseDoor extends Door implements Serializable {
    private String puzzle;
    private String solution;
    private static final long serialVersionUID = 1L;

    /**
     * Constructor for the WiseDoor class.
     *
     * @param description The description of the door.
     * @param room        The room the door leads to.
     * @param puzzle      The puzzle on the door.
     * @param solution    The solution to the puzzle.
     */
    public WiseDoor(String description, Room room, String puzzle, String solution) {
        super(description, room);
        this.puzzle = puzzle;
        this.solution = solution;
    }

    /**
     * Prints the state of the door (open or closed) and the puzzle if the door is closed.
     */
    public void inspect() {
        System.out.println("The door is closed. There is a puzzle written on it.");
    }

    /**
     * Handles the player's interaction with the door.
     * If the door is open, the player moves to the next room.
     * If the door is locked, the player is presented with the puzzle.
     *
     * @param player The player character.
     */
    public void interact(Player player) {
        System.out.println("Thou shalt not pass till riddle be solved:" + puzzle);
        solvePuzzle(player);
    }

    /**
     * Handles the player's attempt to solve the puzzle.
     * The player can keep guessing until they get the correct answer or they give up by typing 'exit'.
     * If the player gets the correct answer, they pass through the door to the next room.
     * @param player The player character.
     */
    public void solvePuzzle(Player player) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("What is your answer?(Exit by typing 'exit')");
            String answer = scanner.nextLine();

            if (answer.equals("exit")) {
                return;
            } else if (answer.equals(solution)) {
                System.out.println("Twas meetly fine to greet thee, wayfarer.");
                player.updateRoom(this.getNextRoom());
                return;
            }

            Troll troll = new Troll();
            troll.makeFunOfPlayer();
        }
    }
}