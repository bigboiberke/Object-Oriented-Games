package nl.rug.oop.rpg;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * The Player class represents a player character in the game.
 * A player has a name, a current room, damage, and health.
 */
public class Player implements Serializable, Damageable {
    private String name;
    private Room currentRoom;
    private int damage;
    private int health;
    private int money;
    private int level;
    private int experience;
    private List<Item> inventory;
    private static final long serialVersionUID = 1L;

    /**
     * Constructs a new Player with the given name and current room.
     * The player starts with 10 damage, 100 health, and 25 money.
     * The player's level starts at 1 and experience starts at 0.
     * The player's inventory is initialized as an empty list.
     *
     * @param name The name of the player.
     * @param currentRoom The room that the player starts in.
     */
    public Player(String name, Room currentRoom){
        this.name = name;
        this.currentRoom = currentRoom;
        this.damage = 3;
        this.health = 100;
        this.money = 25;
        this.level = 1;
        this.experience = 0;
        this.inventory = new ArrayList<>();
    }

    /**
     * Sets the current room of the player.
     *
     * @param room The room to set as the current room.
     */
    public void setRoom(Room room){
        this.currentRoom = room;
    }

    /**
     * Returns the current room of the player.
     *
     * @return The current room of the player.
     */
    public Room getRoom(){
        return currentRoom;
    }

    public int getHealth(){
        return this.health;
    }
    
    public int getDamage(){
        return this.damage;
    }

    public int getMoney(){
        return this.money;
    }
    
    public void updateDamage(int damage){
        this.damage = damage;
    }

    public void updateHealth(int health){
        this.health = health;
    }

    public void updateMoney(int money){
        this.money = money;
    }

    public void updateRoom(Room room){
        this.currentRoom = room;
    }
    
    /**
     * Reduces the health of the player by a specified amount of damage.
     *
     * @param damage The amount of damage to inflict on the player.
     */
    public void takeDamage(int damage){
        this.health -= damage;
        if (this.health <= 0){
            System.out.println("You have died, get good LOOOOOOOOOOOOOL.");
            System.exit(0);
        }
    }

    /**
     * Attacks an enemy by reducing the enemy's health by the player's damage.
     *
     * @param enemy The enemy to attack.
     */
    public void attack(Enemy enemy){
        enemy.takeDamage(this.damage);
    }

    /**
     * Adds an item to the player's inventory.
     *
     * @param item The item to add.
     */
    public void addItemToInventory(Item item){
        this.inventory.add(item);
    }

    /**
     * Shows the player's inventory and stats.
     * The inventory is displayed as a list of item names.
     * The player's stats include health, damage, level, experience, and money.
     * The player's level progress is displayed as a series of dots, with each dot representing 1 experience point.
     *
     */
    public void showInventoryAndStats() {
        System.out.print("Inventory: ");
        if (inventory.isEmpty()){
            System.out.println("Empty");
        } else {
            for (Item item : inventory){
                System.out.println(item.getName());
            }
        }
        System.out.print("Your stats are:\n" +
                "Health: " + this.health + "  |   DPS: " + this.damage +
                "\nLevel: " + this.level + "     |   Level progress: ");
        for (int i = 1; i <= 10; i++) {
            if(this.experience >= i) {
                System.out.print("●");
            } else {
                System.out.print("○");
            }
        }
        System.out.println("\nMoney: " + this.money);
        Timer timer = new Timer();
        timer.stopTime(2200);
        System.out.println();
    }
    /**
     * Handles the player defeating a monster.
     *
     * @param xp    The experience gained.
     * @param money The money gained.
     */

    public void monsterDefeated(int xp, int money) {
        this.experience += xp;
        if (this.experience >= 10) {
            levelUp(xp);
        }
        this.money += money;
    }

    /**
     * Handles the player leveling up.
     *
     * @param xp The experience used to level up.
     */
    public void levelUp(int xp) {
        this.level += xp / 10;
        this.health += 25;
        this.damage += 3;
        this.experience = xp % 10;
        System.out.println("You have leveled up! You are now level " + this.level);
        Timer timer = new Timer();
        timer.stopTime(2000);
    }

}