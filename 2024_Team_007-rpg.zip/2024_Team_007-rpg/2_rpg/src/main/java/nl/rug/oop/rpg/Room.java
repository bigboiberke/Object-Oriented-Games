package nl.rug.oop.rpg;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * The Room class represents a room in the game.
 * It implements the InspectableInterface.
 * A room has a description, a list of doors, and a list of NPCs.
 */
public class Room implements Inspectable, Serializable {
    private String description;
    private List<Door> doors;
    private List<NPC> npcs;
    private static final long serialVersionUID = 1L;

    /**
     * Constructor for the Room class.
     *
     * @param description The description of the room.
     */
    public Room(String description){
        this.description = description;
        this.doors = new ArrayList<>();
        this.npcs = new ArrayList<>();
    }

    /**
     * Returns the door at the specified index.
     *
     * @param index The index of the door.
     * @return The door at the specified index.
     */
    public Door getDoor(int index){
        return doors.get(index);
    }

    /**
     * Returns the NPC at the specified index.
     *
     * @param index The index of the NPC.
     * @return The NPC at the specified index.
     */
    public NPC getNPC(int index){
        return npcs.get(index);
    }

    /**
     * Returns the list of NPCs in the room.
     *
     * @return The list of NPCs in the room.
     */
    public List<NPC> getNPCs(){
        return npcs;
    }

    /**
     * Returns the list of doors in the room.
     *
     * @return The list of doors in the room.
     */
    public List<Door> getDoors(){
        return doors;
    }

    /**
     * Prints the description of the room and the number of doors in the room.
     */
    public void inspect(){
        System.out.println(this.description + ". This room has " + doors.size() + " doors.");
    }

    /**
     * Adds a door to the room.
     *
     * @param door The door to add to the room.
     */
    public void addDoor(Door door){
        doors.add(door);
    }

    /**
     * Adds an NPC to the room.
     *
     * @param npc The NPC to add to the room.
     */
    public void addNPC(NPC npc){
        npcs.add(npc);
    }

    public void removeNPC(NPC npc){
        this.npcs.remove(npc);
    }

    /**
     * Prints the descriptions of all the doors in the room.
     */
    public void inspectDoors(){
        int i = 0;
        for (Door door : doors) {
            System.out.print(" (" + i++ + ") ");
            door.inspect();
        }
    }

    /**
     * Prints the descriptions of all the NPCs in the room.
     */
    public void inspectNPCs(){
        int i = 0;
        for (NPC npc : npcs) {
            System.out.print(" (" + i++ + ") ");
            npc.inspect();
        }
    }
}