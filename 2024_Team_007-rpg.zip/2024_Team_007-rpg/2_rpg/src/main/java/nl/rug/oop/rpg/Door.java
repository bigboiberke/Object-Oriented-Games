package nl.rug.oop.rpg;

import java.io.Serializable;

/**
 * The Door class represents a door in the game.
 * It implements the Inspectable and Interactable.
 * A door has a description and a reference to the next room.
 */
public abstract class Door implements Inspectable, Interactable, Serializable {
    private String description;
    private Room nextRoom;
    private static final long serialVersionUID = 1L;

    /**
     * Constructor for the Door class.
     *
     * @param description The description of the door.
     * @param room        The room the door leads to.
     */

    public Door(String description, Room room) {
        this.description = description;
        this.nextRoom = room;
    }

    /**
     * Returns the next room that this door leads to.
     *
     * @return The next room that this door leads to.
     */
    public Room getNextRoom() {
        return this.nextRoom;
    }

    /**
     * Returns the description of the door.
     *
     * @return The description of the door.
     */
    public String getDescription() {
        return this.description;
    }

    /**
     * Prints the description of the door.
     */
    public void inspect(){
        System.out.println(this.description);
    }

    /**
     * Changes the player's current room to the next room.
     *
     * @param player The player character.
     */
    public void interact(Player player){
        player.setRoom(nextRoom);
    }
}