package nl.rug.oop.rpg;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * The Merchant class represents a merchant NPC in the game.
 * The merchant sells items to the player.
 */
public class Merchant extends NPC implements Serializable {
    private List<Item> items;
    private static final long serialVersionUID = 1L;

    /**
     * Constructs a new Merchant with the given name, damage, and health.
     * Initializes the list of items that the merchant has for sale.
     *
     * @param name The name of the merchant.
     * @param damage The damage that the merchant can inflict.
     * @param health The health of the merchant.
     */
    public Merchant(String name, int damage, int health){
        super(name, damage, health);
        this.items = new ArrayList<>();
    }

    /**
     * Adds an item to the list of items that the merchant has for sale.
     *
     * @param item The item to add.
     */
    public void addItem(Item item){
        items.add(item);
    }

    /**
     * Removes an item from the list of items that the merchant has for sale.
     *
     * @param item The item to remove.
     */
    public void removeItem(Item item){
        items.remove(item);
    }

    /**
     * Handles the interaction between the player and the merchant.
     * The merchant offers to sell items to the player.
     * If the player chooses to buy an item and has enough money, the merchant sells the item to the player.
     *
     * @param player The player character.
     */
    @Override
    public void interact(Player player){
        if (items.isEmpty()){
            System.out.println("Angry Merchant: I'm all out of items. Come back later!");
            return;
        }
        showItems();
        Scanner scanner = new Scanner(System.in);
        if (!scanner.hasNextInt()){
            System.out.println("Angry Merchant: Are you joking? GO AWAY!");
            return;
        }
        int chosenItem = scanner.nextInt();
        if (chosenItem <= -1 || chosenItem >= items.size()){
            System.out.println("Angry Merchant: GO AWAY!");
            return;
        }
        sellItem(player, chosenItem);
    }

    /**
     * Prints the list of items that the merchant has for sale.
     */
    public void showItems(){
        System.out.println("Angry Merchant: Welcome to my shop! I can offer these items:");
        int i = 0;
        for (Item item : items){
            System.out.println( " <" + i++ + "> " + item.getName() + "   |   " + item.getValue() + " gold.");
        }
        System.out.println("Would you like to buy something?(-1 to leave)");
    }

    /**
     * Sells the chosen item to the player.
     * If the player has enough money, the item is added to the player's inventory
     * and the player's money is decreased by the value of the item.
     * If the player does not have enough money, the merchant informs them of this.
     *
     * @param player The player character.
     * @param chosenItem The index of the chosen item in the list of items.
     */
    public void sellItem(Player player, int chosenItem){
        Item wantedItem = items.get(chosenItem);

        if (player.getMoney() >= wantedItem.getValue()) {
            player.updateMoney(player.getMoney() - wantedItem.getValue());
            player.addItemToInventory(wantedItem);
            System.out.println("Angry Merchant: Thank you for your purchase!");
            removeItem(wantedItem);
        } else {
            System.out.println("Angry Merchant: You don't have enough gold, sorry.");
        }
    }
}