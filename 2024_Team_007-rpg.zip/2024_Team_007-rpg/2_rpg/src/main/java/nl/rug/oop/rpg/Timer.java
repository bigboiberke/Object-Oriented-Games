package nl.rug.oop.rpg;

/**
 * The Timer class provides a method to pause the execution of the program for a specified amount of time.
 */
public class Timer {
    /**
     * Pauses the execution of the program for a specified amount of time.
     *
     * @param time The amount of time to pause in milliseconds.
     */
    public void stopTime(int time) {
        try {
            Thread.sleep(time);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}