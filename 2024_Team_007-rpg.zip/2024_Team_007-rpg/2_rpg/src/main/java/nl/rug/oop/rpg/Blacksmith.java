package nl.rug.oop.rpg;

import java.io.Serializable;
import java.util.Scanner;

/**
 * The Blacksmith class represents a blacksmith NPC in the game.
 * The blacksmith can upgrade the player's armor for a cost.
 */
public class Blacksmith extends NPC implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
     * Constructs a new Blacksmith with the given name, damage, and health.
     *
     * @param name The name of the blacksmith.
     * @param damage The damage that the blacksmith can inflict.
     * @param health The health of the blacksmith.
     */

    public Blacksmith(String name, int damage, int health){
        super(name, damage, health);
    }

    /**
     * Handles the interaction between the player and the blacksmith.
     * The blacksmith offers to upgrade the player's armor for 10 coins.
     * If the player chooses to upgrade and has enough money, the blacksmith
     * upgrades the player's armor.
     *
     * @param player The player character.
     */
    public void interact(Player player){
        System.out.println("Blacksmith: I can upgrade your armor for 10 coins." +
                " Do you want to upgrade? (To upgrade type yes)");
        Scanner scanner = new Scanner(System.in);
        String choice = scanner.nextLine();
        if (choice.equals("yes")){
            if (player.getMoney() >= 10){
                player.updateMoney(player.getMoney() - 10);
                this.upgradeArmor(player);
            } else {
                System.out.println("Blacksmith: You don't have enough gold, sorry.");
            }
        }
    }

    /**
     * Upgrades the player's armor.
     * The method simulates the upgrading process by printing a series of dots over a period of time.
     * After the upgrading is completed, the player's health is increased by 5.
     *
     * @param player The player character.
     */
    public void upgradeArmor(Player player){
        Timer timer = new Timer();
        System.out.print("Upgrading armor ");
        for (int i = 1; i <= 10; i++) {
            System.out.print("● ");
            timer.stopTime(1000);
        }
        player.updateHealth(player.getHealth() + 5);
        System.out.println("Your armor has been upgraded! " +
                "Your hit points are now " + player.getHealth() + ".");
    }
}