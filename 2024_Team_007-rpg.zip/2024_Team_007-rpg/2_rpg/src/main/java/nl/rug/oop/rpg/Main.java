package nl.rug.oop.rpg;

/**
 * The Main class is the entry point of the game.
 * It creates a new Game object and starts the game.
 */
public class Main {
    /**
     * The main method is the entry point of the Java application.
     * It creates a new Game object and calls the startGame method to start the game.
     *
     * @param args The command-line arguments passed to the application. This parameter is not used in this application.
     */
    public static void main(String[] args) {
        Game game = new Game();
        game.startGame();
    }
}