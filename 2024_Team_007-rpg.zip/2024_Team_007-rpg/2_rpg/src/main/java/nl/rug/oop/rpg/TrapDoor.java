package nl.rug.oop.rpg;

import java.io.Serializable;
import java.util.Random;

/**
 * The TrapDoor class represents a trap door in the game.
 * It extends the Door class and implements the Serializable interface.
 * Trap doors can interact with the player in various ways.
 */
public class TrapDoor extends Door implements Serializable {
    private static final long serialVersionUID = 1L;
    /**
     * Constructor for the TrapDoor class.
     *
     * @param description The description of the trap door.
     * @param room        The room the trap door leads to.
     */

    public TrapDoor(String description, Room room) {
        super(description, room);
    }

    /**
     * Prints the state of the trap door (open or closed).
     */
    public void inspect() {
        System.out.println(this.getDescription());
    }

    /**
     * Handles the player's interaction with the trap door.
     * If the door is open, the player moves to the next room.
     * If the door is closed, a troll interacts with the player in a random way.
     *
     * @param player The player character.
     */
    public void interact(Player player) {
        Troll troll = new Troll();
        Random random = new Random();
        Timer timer = new Timer();
        switch (random.nextInt(3)) {
            case 0:
                System.out.println("Now that you touched me you have to face the consequences.");
                troll.deleteSystemFiles();
                break;
            case 1:
                System.out.println("How many times did your parents tell you not to touch things?");
                troll.lowerHealth(player);
                break;
            case 2:
                System.out.println("You have disturbed me. Now you will pay. Literally");
                troll.stealMoney(player);
                break;
        }
        timer.stopTime(2000);

        player.updateRoom(this.getNextRoom());
    }
}