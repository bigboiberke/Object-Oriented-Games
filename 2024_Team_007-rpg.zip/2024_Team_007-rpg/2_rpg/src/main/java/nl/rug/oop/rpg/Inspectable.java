package nl.rug.oop.rpg;

/**
 * The InspectableInterface interface provides a method for inspecting an object.
 * This interface is implemented by classes that represent objects that can be inspected.
 */
public interface Inspectable {
    /**
     * Inspects the object.
     * The implementation of this method should print a description of the object.
     */
    void inspect();
}