package nl.rug.oop.rpg;

import java.util.Random;

/**
 * The Troll class represents a troll in the game.
 * Trolls can interact with the player in various ways,
 * such as deleting system files, stealing money, or lowering health.
 */
public class Troll {

    /**
     * Simulates the troll deleting the player's system files.
     * This is represented by printing a series of messages to the console.
     */
    public void deleteSystemFiles() {
        System.out.println("Operation \"Deleting \"C:\\Windows\\System32\" has been initiated\".\n" +
                "Please wait...");
        Timer timer = new Timer();
        timer.stopTime(2000);
        for (int i = 0; i <= 100; i += 10) {
            System.out.println("Deleting files in \"C:\\Windows\\System32\" " + i + "%");
            Random random = new Random();
            timer.stopTime(random.nextInt(400));
        }
        System.out.println("Operation \"Deleting \"C:\\Windows\\System32\" has been completed\".");
        timer.stopTime(1000);
    }

    /**
     * Simulates the troll stealing money from the player.
     * If the player has less than 10 coins, the troll lets them go.
     * Otherwise, the troll takes 10 coins and updates the player's money.
     *
     * @param player The player character.
     */
    public void stealMoney(Player player) {

        if(player.getMoney() < 10) {
            System.out.println("Boy, you are broke. I will let you go this time... But you owe me.");
            return;
        }

        player.updateMoney(player.getMoney() - 10);
        System.out.println(
            "You don't need this 10 coins, right?" +
            "You now have " + player.getMoney() + " coins."
        );
    }

    /**
     * Simulates the troll lowering the player's health.
     * The player's health is updated to 1.
     *
     * @param player The player character.
     */
    public void lowerHealth(Player player) {
        player.updateHealth(1);
        System.out.println("Your health has been lowered to 1. You are lucky I am nice.");
    }

    /**
     * Simulates the troll making fun of the player.
     * The troll randomly selects one of four insults to say to the player.
     */
    public void makeFunOfPlayer(){
        Random random = new Random();
        switch (random.nextInt(4)){
            case 0:
                System.out.println("Haha, you are not even close to the answer.");
                break;
            case 1:
                System.out.println("Even a rat could answer this.");
                break;
            case 2:
                System.out.println("Really...? That's your answer? Pathetic.");
                break;
            case 3:
                System.out.println("Are you even trying?");
                break;
        }
    }
}