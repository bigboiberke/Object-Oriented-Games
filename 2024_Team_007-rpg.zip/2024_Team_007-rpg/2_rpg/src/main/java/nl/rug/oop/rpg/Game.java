package nl.rug.oop.rpg;

import java.io.*;
import java.util.Scanner;

/**
 * The Game class represents the main game logic.
 * It provides methods for the player to make choices in the game.
 * This class implements Serializable interface to support saving and loading game state.
 */
public class Game implements Serializable {
    // The player character
    private Player player;
    // A unique identifier for this version of the class, used in serialization
    private static final long serialVersionUID = 1L;

    /**
     * Starts the game by setting up the game world and entering the game loop.
     */
    public void startGame() {
        // Check if the save directory exists. If not, create it.
        saveDir();
        // Create the first room with a description.
        Room room = new Room("THIS IS FIRST ROOM");
        Room room2 = new Room("THIS IS SECOND ROOM");
        // Create the player with a name, level, and health.
        this.player = new Player("THIS IS ME", room);
        // Create doors.
        TrapDoor trapDoor = new TrapDoor("THIS IS A TRAP DOOR", room2);
        WiseDoor wiseDoor = new WiseDoor("THIS IS A WISE DOOR", room2, "What has keys but can't open locks?", "piano");
        // Create NPCs.
        Enemy enemy = new Enemy("THIS IS AN ENEMY", 10, 10);
        Enemy enemy1 = new Enemy("Goblin", 20, 5);
        Enemy enemy2 = new Enemy("Skeleton", 15, 8);
        Enemy enemy3 = new Enemy("Orc", 30, 12);
        Trainer trainer = new Trainer("THIS IS A TRAINER", 10, 10);
        Merchant angryMerchant = new Merchant("THIS IS AN ANGRY MERCHANT", 10, 10);
        Blacksmith blacksmith = new Blacksmith("THIS IS A BLACKSMITH", 10, 10);
        // Create an item with a name and value.
        Item item = new Item("THIS IS AN ITEM", 10);
        angryMerchant.addItem(item);
        // Add the NPCs.
        room.addNPC(enemy);
        room.addNPC(trainer);
        room.addNPC(angryMerchant);
        room2.addNPC(enemy1);
        room2.addNPC(enemy2);
        room2.addNPC(enemy3);
        room2.addNPC(blacksmith);
        // Add doors to the first room.
        room.addDoor(trapDoor);
        room.addDoor(wiseDoor);
        // Display the game's prologue text.
        prologue();
        // Start the game loop.
        gameChoice();
    }

    /**
     * Checks if the save directory exists. If not, creates it.
     */
    public void saveDir() {
        String userHomeDir = System.getProperty("user.dir");
        File saveDirectory = new File(userHomeDir + "\\savedgames");
        if (!saveDirectory.exists()) {
            saveDirectory.mkdirs(); // Use mkdirs() to create parent directories if they don't exist
            System.out.println("INFO: Save directory created.");
        }
    }

    /**
     * Displays the game's prologue text.
     */
    public void prologue() {
        System.out.println(
                "Welcome to the RPG Game!\nIn the realm of Azeroth, The Wanderer " +
                        "embarks on a daunting quest into \"The Shattered Throne\" dungeon, once a grand" +
                        " palace now overrun with dark forces.Armed with sword\nand shield, The Wanderer" +
                        " navigates treacherous traps, battles fierce creatures, and unravels ancient mysteries." +
                        " Every step brings closer to the heart of darkness, where\nforgotten evils lurk. Will The" +
                        " Wanderer emerge triumphant, a hero of legend, or succumb to the shadows, lost forever in" +
                        " the depths of \"The Shattered Throne\"?"
        );
        System.out.println("Press enter to continue...");
        Scanner scanner = new Scanner(System.in);
        scanner.nextLine();
    }

    /**
     * Prints the available options for the player.
     */
    public void printOptions() {
        System.out.println("What would you like to do?");
        System.out.println("0: Inspect the room");
        System.out.println("1: Look for a way out");
        System.out.println("2: Look for company");
        System.out.println("3: Quick save");
        System.out.println("4: Quick load");
        System.out.println("5: Save");
        System.out.println("6: Load");
        System.out.println("7: Show inventory and stats");
        System.out.println("8: Exit");
    }

    /**
     * Provides the player with a set of choices and executes the chosen action.
     * The player can inspect the room, look for a way out, or look for company.
     * The method loops indefinitely, allowing the player to make multiple choices.
     */
    public void gameChoice() {
        while (true) {
            Scanner scanner = new Scanner(System.in);
            printOptions();
            if (!scanner.hasNextInt()) {
                System.out.println("Invalid option!");
                continue;
            }
            executeChoice(scanner.nextInt());
            Timer timer = new Timer();
            timer.stopTime(1000);
        }
    }

    /**
     * Executes the player's chosen action.
     * The player can inspect the room, look for a way out,
     * look for company, quick save, quick load, save, load, or exit.
     *
     * @param choice The player's chosen action.
     */
    public void executeChoice(int choice) {
        switch (choice) {
            case 0:
                this.player.getRoom().inspect();
                break;
            case 1:
                lookForWayOut(this.player, this.player.getRoom());
                break;
            case 2:
                lookForCompany(this.player, this.player.getRoom());
                break;
            case 3:
                save(1, this.player);
                break;
            case 4:
                Player tempPlayer = load(1);
                if (tempPlayer != null) {
                    this.player = tempPlayer;
                }
                break;
            case 5:
                save(0, this.player);
                break;
            case 6:
                tempPlayer = load(0);
                if (tempPlayer != null) {
                    this.player = tempPlayer;
                }
                break;
            case 7:
                this.player.showInventoryAndStats();
                break;
            case 8:
                System.exit(0);
                break;
            default:
                System.out.println("Invalid option!");
                break;
        }
    }

    /**
     * Handles the logic for the player looking for a way out of the current room.
     * The player can interact with doors in the room.
     *
     * @param player      The player character.
     * @param currentRoom The current room the player is in.
     */
    public void lookForWayOut(Player player, Room currentRoom) {
        if (currentRoom.getDoors().isEmpty()) {
            System.out.println("There are no doors in this room.");
            return;
        }
        System.out.println("You look around for doors. You see: (-1 to exit)");

        while (true) {
            currentRoom.inspectDoors();
            Scanner scanner = new Scanner(System.in);

            if (!scanner.hasNextInt()) {
                System.out.println("Invalid input!");
                continue;
            }

            int choice = scanner.nextInt();

            if (choice == -1) {
                break;
            } else if (choice < -1 || choice >= currentRoom.getDoors().size()) {
                System.out.println("Invalid option!");
            } else {
                // Interact with the chosen door
                currentRoom.getDoor(choice).interact(player);
                break;
            }
        }
    }

    /**
     * Handles the logic for the player looking for company in the current room.
     * The player can interact with NPCs in the room.
     *
     * @param player      The player character.
     * @param currentRoom The current room the player is in.
     */
    public void lookForCompany(Player player, Room currentRoom) {
        if (currentRoom.getNPCs().isEmpty()) {
            System.out.println("There are no NPCs in this room.");
            return;
        }
        System.out.println("You look around for company. You see: (-1 to exit)");
        while (true) {
            currentRoom.inspectNPCs();
            Scanner scanner = new Scanner(System.in);

            if (!scanner.hasNextInt()) {
                System.out.println("Invalid input!");
                continue;
            }

            int choice = scanner.nextInt();
            if (choice == -1) {
                break;
            } else if (choice < -1 || choice >= currentRoom.getNPCs().size()) {
                System.out.println("Invalid option!");
            } else {
                // Interact with the chosen NPC
                currentRoom.getNPC(choice).interact(player);
                break;
            }
        }
    }

    /**
     * This method is used to save the current state of the game.
     * It serializes the Player object and writes it to a file.
     * The file is either a quick save file or a user-named file based on the quickSave parameter.
     *
     * @param quickSave An integer indicating whether the save is a quick save (1) or not (0).
     * @param player    The Player object that is to be saved.
     */
    public void save(int quickSave, Player player) {
        String userHomeDir = System.getProperty("user.dir");
        if (quickSave == 1) {
            userHomeDir += "\\savedgames\\quickSave.ser";
        } else {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter the name of the save file:");
            String saveName = scanner.nextLine();
            userHomeDir += "\\savedgames\\" + saveName + ".ser";
        }
        try (FileOutputStream fileOut = new FileOutputStream(userHomeDir);
             ObjectOutputStream out = new ObjectOutputStream(fileOut)) {

            out.writeObject(player);
            System.out.println("Data has been saved!");

        } catch (IOException i) {
            i.printStackTrace();
        }
    }

    /**
     * This method is used to load a saved game state.
     * It reads a serialized Player object from a file and returns it.
     * The file is either a quick load file or a user-selected file based on the quickLoad parameter.
     *
     * @param quickLoad An integer indicating whether the load is a quick load (1) or not (0).
     * @return The Player object that was loaded from the file.
     */
    public Player load(int quickLoad) {
        String userHomeDir = System.getProperty("user.dir");
        if (quickLoad == 1) {
            userHomeDir += "\\savedgames\\quickSave.ser";
        } else {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter the index of the save file:");
            printSaveFiles(userHomeDir + "\\savedgames");
            File saveDirectory = new File((userHomeDir + "\\savedgames"));
            File[] saveFiles = saveDirectory.listFiles();
            if (saveFiles == null || !scanner.hasNextInt()) {
                System.out.println("No such files found.");
                return null;
            }
            int choice = scanner.nextInt();
            if (choice < 0 || choice >= saveFiles.length) {
                System.out.println("No save files found.");
                return null;
            }
            userHomeDir = userHomeDir + "\\savedgames\\" + saveFiles[choice].getName();
        }
        File saveFile = new File(userHomeDir);
        // Check if the file exists
        if (saveFile.exists()) {
            try (FileInputStream fileIn = new FileInputStream(saveFile);
                ObjectInputStream retrievedObject = new ObjectInputStream(fileIn)) {
                Player player = (Player) retrievedObject.readObject();
                System.out.println("Data has been loaded!");
                return player;
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("Save file does not exist.");
        }
        return null;
    }

    /**
     * This method is used to print the names of all save files in the save directory.
     *
     * @param saveFilesDir The directory where the save files are located.
     */
    public void printSaveFiles(String saveFilesDir) {
        File saveDirectory = new File(saveFilesDir);
        File[] saveFiles = saveDirectory.listFiles();
        int i = 0;
        System.out.println("Available save files:");
        for (File file : saveFiles) {
            System.out.println(" (" + i++ + ") " + file.getName());
        }
    }
}