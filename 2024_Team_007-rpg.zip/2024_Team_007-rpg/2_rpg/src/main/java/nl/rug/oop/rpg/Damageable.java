package nl.rug.oop.rpg;

/**
 * The Damageable interface represents entities in the game that can take damage.
 * This is a functional interface whose functional method is takeDamage(int).
 */
public interface Damageable {

    /**
     * Applies damage to the entity.
     *
     * @param damage The amount of damage to be applied.
     */
    void takeDamage(int damage);
}